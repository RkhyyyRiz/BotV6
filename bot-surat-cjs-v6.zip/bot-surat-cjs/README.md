# Bot Surat Masuk (CommonJS)

## Jalankan di GitHub Codespaces
1. Upload isi folder ini ke repo GitHub **private** (file `.env` dan `auth_info/` sudah di .gitignore).
2. Repo > Settings > Secrets and variables > Codespaces > New secret: `GEMINI_API_KEY` = key Gemini kamu.
3. Klik Code > Codespaces > Create codespace on main. `npm install` dan pembuatan `.env` jalan otomatis.
4. Buka `.env`, sesuaikan `ALLOWED_NUMBERS` (opsional).
5. Di terminal: `npm start`
6. Scan QR di terminal: WhatsApp > Perangkat tertaut > Tautkan perangkat.
7. Kirim/forward PDF surat ke nomor bot. Perintah: `!rekap`, `!bantuan`.

Sesi logout / QR bermasalah: `npm run reset-sesi` lalu `npm start` lagi.

## API key AI: lewat halaman web (cocok untuk Codespace di HP)
Buka halaman web bot (`http://localhost:3000`; di Codespaces tab **PORTS** lalu ikon globe di port 3000, di HP bisa lewat ikon globe/Open in Browser). Di bagian **API key AI**:
1. Tempel key di kolom, lalu **Simpan**. Penyedia dikenali otomatis: `AIza...` = Gemini, `sk-...` = OpenAI.
2. Key diuji ke penyedia dulu; bila ditolak, tidak disimpan. Status tampil sebagai `••••` + 4 karakter terakhir (key utuh tidak pernah dikirim balik ke browser).
3. Langsung aktif tanpa memulai ulang bot. Tombol **Hapus** menghapus key yang diisi lewat web.

Catatan:
- Key dari web disimpan di `data/keys.json` (izin 0600, folder `data/` sudah di `.gitignore`), sehingga bot yang dijalankan ulang otomatis (supervisor, Codespace menyala lagi) **tidak perlu ditempel lagi**. Key ini menimpa key dari `.env` / Secret.
- Terminal tetap bisa dipakai: saat `npm start`, bila belum ada key sama sekali, muncul pertanyaan tempel key (`AIza...` / `sk-...`). Pertanyaan ini **tidak memblokir bot** dan otomatis tertutup bila key sudah diisi lewat web. Di Codespace yang menyala otomatis (tanpa terminal) tidak ada pertanyaan; pakai web.
- Alternatif lain tetap didukung: Codespaces Secrets (`GEMINI_API_KEY`, `OPENAI_API_KEY`) atau `.env`. Isi keduanya (Gemini dan OpenAI) agar ada cadangan bila kuota habis (429).

## Koneksi WhatsApp: QR, kode pairing, dan sambung ulang otomatis
`npm start` menjalankan bot lewat *supervisor*: bot langsung berjalan (tidak menunggu input), dan bila proses mati/crash, bot hidup lagi sendiri (jeda 1-30 detik) tanpa menanyakan apa pun.
Tambahan sambung ulang di dalam bot:
- Koneksi putus biasa: sambung ulang otomatis dengan jeda bertahap (2 detik sampai 1 menit). Sesi tetap dipakai, **tidak perlu scan ulang**.
- Setelah tautan berhasil WhatsApp memang meminta restart koneksi sebentar; itu normal.
- Sesi dikeluarkan dari HP (logout) atau rusak berulang: sesi lama dipindah ke `auth_info.bak` dan bot siap ditautkan ulang (QR / kode pairing muncul lagi). Tautan ulang tetap harus dilakukan dari HP.
- File sesi rusak otomatis dipindah ke cadangan. Koneksi yang macet lebih dari 3 menit di-reset oleh watchdog.
- Error beruntun (3x dalam 1 menit): koneksi di-reset; 8x: proses dimulai ulang oleh supervisor/pm2.

**Menautkan WhatsApp** (tiga cara, semuanya bisa dipakai bersamaan):
1. **QR di terminal**: scan lewat WhatsApp > Perangkat tertaut > Tautkan perangkat.
2. **Halaman web** `http://localhost:3000`: QR tampil sebagai gambar, ada kolom nomor untuk meminta kode pairing, serta tombol *Mulai ulang koneksi* dan *Reset sesi*. Di Codespaces buka tab **PORTS** lalu klik ikon globe di port 3000.
3. **Kode pairing**: isi nomor WhatsApp bot (mis. `0812xxxx`) di halaman web, atau di terminal saat `npm start` (pertanyaan paralel, bisa dilewati); kode 8 karakter muncul di terminal **dan** di halaman web. Di HP pilih *Tautkan dengan nomor telepon saja*. Kode dibuat ulang otomatis tiap 2,5 menit selama belum dipakai. Bila gagal dibuat, QR tetap bisa dipakai.

Halaman web hanya bisa dibuka dari komputer yang sama (`127.0.0.1`). Di VPS akses lewat SSH tunnel: `ssh -L 3000:localhost:3000 user@server`.
Tanpa supervisor (mis. memakai pm2): `npm run start:direct`; isi key lewat halaman web atau `.env` karena pm2 tidak punya terminal interaktif.

## Menjalankan terus di GitHub Codespaces
Codespace yang idle akan berhenti total (termasuk bot), dan program di dalamnya tidak bisa menghidupkan dirinya lagi. Yang dilakukan paket ini:
1. **Bot menyala otomatis tiap Codespace hidup** (`postStartCommand` di `.devcontainer`), berjalan di latar belakang dengan log di `bot.log`. Sesi WhatsApp (`auth_info/`) tersimpan di disk Codespace, jadi **tidak perlu scan ulang**.
   - Proses latar belakang tidak punya terminal, jadi isi key lewat **halaman web** (tersimpan di `data/keys.json`, bertahan setelah Stop/Start) atau lewat **Codespaces Secrets** / `.env`. Setelah menambah/mengubah Secret, **Stop lalu Start** Codespace.
   - Lihat log: `npm run log`. Hentikan: `npm run stop`. Bot hanya boleh satu per sesi: `npm start` kedua otomatis ditolak dengan pesan "sudah berjalan".
2. **Mencegah cepat berhenti**: atur *Default idle timeout* ke 240 menit (GitHub > Settings > Codespaces; maksimal 4 jam). Selain itu bot mencetak satu baris status tiap 5 menit (`HEARTBEAT_MIN`); menurut dokumentasi GitHub, keluaran terminal me-reset timer idle, jadi cara paling efektif adalah menjalankan `npm run log` di terminal VS Code dan membiarkannya terbuka.
3. **Opsional, bangunkan dari luar**: workflow `.github/workflows/bangunkan-codespace.yml` mengecek tiap 20 menit dan menyalakan Codespace yang berhenti. Perlu secret repo `CODESPACE_PAT` (token klasik dengan scope `codespace`). Jadwal Actions bisa telat, jadi akan ada jeda mati beberapa menit.

Catatan penting: Codespaces untuk pengembangan, bukan hosting. Kuota gratis bulanannya terbatas (cek GitHub > Settings > Billing; mesin 2-core hanya sekitar puluhan jam per bulan), jadi 24 jam penuh sebulan tidak akan cukup di akun gratis. Untuk 24/7 sungguhan tetap butuh VPS atau perangkat yang menyala terus.

## Pesan yang masuk saat bot mati
Pesan (PDF atau perintah) yang dikirim ketika bot mati / putus **tetap dibalas begitu bot tersambung kembali**:
- WhatsApp menyimpan pesan itu dan mengirimnya saat bot online lagi. Bot memprosesnya berurutan, dan balasan diberi catatan `🕘 Bot sempat offline, pesan ini baru dibalas sekarang.`
- Pesan yang sudah diterima tetapi belum selesai dibalas (bot mati di tengah proses, atau koneksi putus saat membalas) dicatat di `data/inbox.json` lalu dilanjutkan otomatis saat tersambung. Setiap pesan dicoba maksimal 3 kali, dan pesan yang sama tidak pernah dibalas dua kali.
- Batas umur pesan lama: `OFFLINE_REPLY_HOURS` (bawaan 48 jam; pesan yang lebih tua dilewati; `0` = jangan balas pesan lama).
- Batasan: WhatsApp hanya mengantar pesan tertunda ke perangkat tertaut yang tidak terlalu lama offline (perangkat tertaut yang offline sekitar 14 hari dikeluarkan), dan pesan yang gagal didekripsi saat offline tidak bisa dipulihkan bot.

## Surat masuk / keluar (otomatis)
Tidak ada perintah khusus. Bot membaca kop surat:
- Kop **Badan Perencanaan Pembangunan Daerah Penelitian dan Pengembangan Kota Banjarmasin** = **surat keluar**.
- Kop lain (dinas, bappeda kabupaten/kota lain, provinsi, pusat) = **surat masuk**.
- Surat keluar mengisi *Tujuan* (penerima "Yth."), surat masuk mengisi *Pengirim* (kop).
- Rekap terpisah: `data/rekap_surat_masuk.xlsx` dan `data/rekap_surat_keluar.xlsx`.
- Aturan kop bisa diubah lewat `OWN_KOP` di `.env`.

Perintah: `.rekap` (kedua file), `.rekap masuk`, `.rekap keluar`, `.bantuan`.

## Memperbarui API key / kode di Codespaces
- **API key**: GitHub > repo > Settings > Secrets and variables > Codespaces > edit `GEMINI_API_KEY`. Lalu **Stop dan Start Codespace** (terminal lama tidak membaca secret baru) dan jalankan `npm start`.
  Jika muncul peringatan "GEMINI_API_KEY tidak terbaca", berarti key belum masuk. Jangan menaruh key di chat atau di file yang di-commit.
- **Kode**: ganti file lewat panel Explorer Codespaces (drag-drop atau upload zip lalu `unzip -o bot-surat-cjs-fixed.zip`), lalu `git add . && git commit -m "perbaikan" && git push`.
  Folder `auth_info/` dan `data/` jangan ikut terhapus (sesi WhatsApp dan rekap ada di sana).

## Fitur
- Terima PDF surat (kirim langsung atau forward), balas isian siap salin ke e-office.
- Baca PDF digital (teks) dan PDF scan (OCR lewat Gemini).
- Pembacaan ganda: AI Gemini sebagai sumber utama, Regex sebagai cadangan dan pengisi field kosong.
- Deteksi otomatis surat masuk / keluar dari kop surat (`OWN_KOP`).
- Deteksi status surat: Biasa, Undangan, Kunjungan; field acara (tanggal, jam, tempat) hanya untuk Undangan/Kunjungan.
- Rekap Excel terpisah (masuk dan keluar), nomor surat ganda tidak dicatat ulang.
- Penanda "Perlu dicek manual" untuk field wajib yang kosong; catatan jika AI gagal atau PDF dibaca dari scan.
- Pembatasan akses lewat `ALLOWED_NUMBERS`, grup bisa diaktifkan lewat `ALLOW_GROUPS`.
- AI tahan gangguan: coba ulang otomatis untuk 429/5xx/jaringan, batas waktu 45 detik, pesan error jelas.

## Alur kerja
1. PDF masuk ke WhatsApp > bot memeriksa pengirim (nomor, grup) > masuk antrean (satu per satu).
2. Teks PDF diambil. Kurang dari 50 karakter = scan.
3. Scan: dikirim utuh ke Gemini. Digital: Regex + Gemini membaca teks, hasil digabung.
4. Jika teks digital ternyata tidak memuat nomor dan perihal (mis. PDF TTE), gambar dibaca ulang oleh Gemini.
5. Kop surat dibandingkan dengan `OWN_KOP` > masuk atau keluar.
6. Hasil dicatat ke Excel dan dibalas ke chat.

## Pengaturan AI (.env)
| Variabel | Fungsi |
|---|---|
| `USE_AI` | `true` untuk mengaktifkan AI |
| `AI_PROVIDER` | Penyedia utama: `gemini` (bawaan) atau `openai`. Penyedia satunya jadi cadangan jika key-nya ada |
| `GEMINI_API_KEY` / `OPENAI_API_KEY` | Key tiap penyedia. `AI_API_KEY` (lama) = key penyedia utama |
| `AI_MODEL` | Kosong = bawaan, urut: OpenAI `gpt-6.1-terra` > `gpt-5.6-terra` > `gpt-5.4-mini`; Gemini `gemini-3.6-flash` > `3.5-flash-lite` > `3.5-flash`. Bisa satu atau beberapa model dipisah koma. Jika model tidak tersedia, tanpa akses, atau sedang sibuk (503), bot beralih otomatis ke berikutnya |
| `AI_THINKING` | `low` (bawaan), atau minimal/medium/high |
| `AI_BASE_URL` | Khusus layanan kompatibel OpenAI selain OpenAI |

**Jadikan OpenAI penyedia utama:** set `AI_PROVIDER=openai` di `.env`. Key bisa dari Codespaces Secret `OPENAI_API_KEY` atau diketik di terminal saat `npm start`.
Baris pertama log akan menampilkan penyedia dan model yang aktif, mis. `mode parsing: AI [gemini: gemini-3.6-flash > ...  ||  openai: gpt-6.1-terra > ...] + Regex`.
Catatan: OCR PDF scan dikirim sebagai file PDF; tidak semua model/layanan menerima PDF, jika gagal bot memberi tahu lewat balasan.

## Kirim ke nomor sendiri
Buka chat "Pesan ke diri sendiri" di WhatsApp nomor bot, lalu kirim atau forward PDF surat (atau ketik `.rekap`). Bot langsung memproses dan membalas di chat itu. Nomor sendiri selalu diizinkan walau `ALLOWED_NUMBERS` diisi. Pesan keluar ke nomor lain tetap diabaikan.
