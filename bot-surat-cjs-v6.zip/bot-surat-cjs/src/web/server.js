const http = require('node:http');
const { state, LABELS } = require('../whatsapp/state');
const { config } = require('../config');
const keyStore = require('../utils/keyStore');
const PAGE = require('./page');

// QR ke SVG memakai mesin QR bawaan qrcode-terminal (tanpa dependensi tambahan).
let QRCode = null;
let QRErrorCorrectLevel = null;
try {
  QRCode = require('qrcode-terminal/vendor/QRCode');
  QRErrorCorrectLevel = require('qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel');
} catch {}

let svgCache = { text: '', svg: null };
function qrToSvg(text) {
  if (!QRCode) return null;
  if (svgCache.text === text) return svgCache.svg;
  try {
    const qr = new QRCode(-1, QRErrorCorrectLevel.L);
    qr.addData(text);
    qr.make();
    const n = qr.getModuleCount();
    const dark = (r, c) => (typeof qr.isDark === 'function' ? qr.isDark(r, c) : qr.modules[r][c]);
    const margin = 4;
    let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (dark(r, c)) d += `M${c + margin} ${r + margin}h1v1h-1z`;
    const size = n + margin * 2;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
    svgCache = { text, svg };
    return svg;
  } catch (e) {
    console.warn('[web] gagal membuat gambar QR:', e.message);
    return null;
  }
}

const PROVIDER_LABEL = { gemini: 'Gemini', openai: 'OpenAI' };

/** Status key AI untuk halaman web: hanya 4 karakter terakhir, key utuh tidak pernah dikirim ke browser. */
function aiSnapshot() {
  const stored = keyStore.read();
  const out = { enabled: config.useAI, disabledByEnv: process.env.USE_AI === 'false', providers: {} };
  for (const name of keyStore.PROVIDERS) {
    const key = config.keys[name] || '';
    out.providers[name] = {
      label: PROVIDER_LABEL[name],
      set: !!key,
      masked: keyStore.mask(key),
      source: !key ? '' : stored[name] ? 'web' : 'env',
      primary: name === config.aiProvider,
    };
  }
  return out;
}

/** Uji key ke server penyedia. true = valid, false = ditolak, null = tidak bisa diuji (jaringan/server). */
async function verifyKey(provider, key) {
  try {
    const res =
      provider === 'gemini'
        ? await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1', {
            headers: { 'x-goog-api-key': key },
            signal: AbortSignal.timeout(8000),
          })
        : await fetch(`${config.aiBaseUrl}/models`, {
            headers: { authorization: `Bearer ${key}` },
            signal: AbortSignal.timeout(8000),
          });
    if (res.ok) return true;
    if ([400, 401, 403].includes(res.status)) return false;
    return null;
  } catch {
    return null;
  }
}

async function saveKey(body) {
  const key = keyStore.cleanKey(body.key);
  if (key.length < 20 || key.length > 400 || /[^\x21-\x7e]/.test(key)) {
    return { ok: false, error: 'Key tidak valid. Tempel seluruh key (Gemini diawali AIza, OpenAI diawali sk-).' };
  }
  const wanted = keyStore.PROVIDERS.includes(body.provider) ? body.provider : null;
  const provider = keyStore.detectProvider(key, wanted || config.aiProvider);
  const verified = await verifyKey(provider, key);
  if (verified === false) {
    return { ok: false, error: `Key ditolak oleh ${PROVIDER_LABEL[provider]}. Periksa lagi key-nya (jangan ada yang terpotong).` };
  }
  keyStore.save(config, provider, key);
  console.log(`🔑 API key ${provider} disimpan dari halaman web (${keyStore.mask(key)}${verified ? ', terverifikasi' : ', belum bisa diverifikasi'}).`);
  return {
    ok: true,
    provider,
    label: PROVIDER_LABEL[provider],
    verified,
    warning: verified === null ? 'Key disimpan, tetapi belum bisa diverifikasi (jaringan/server sibuk).' : '',
    redirected: wanted && wanted !== provider ? PROVIDER_LABEL[provider] : '',
  };
}

function deleteKey(body) {
  const provider = body.provider;
  if (!keyStore.PROVIDERS.includes(provider)) return { ok: false, error: 'Penyedia tidak dikenal.' };
  keyStore.remove(config, provider, config.envKeys[provider]);
  console.log(`🔑 API key ${provider} yang diisi lewat web dihapus.`);
  return { ok: true };
}

function snapshot() {
  const p = state.pairing || {};
  return {
    status: state.status,
    label: LABELS[state.status] || state.status,
    note: state.note,
    retry: state.retry,
    user: state.user,
    uptime: Math.floor(process.uptime()),
    ai: aiSnapshot(),
    qrSvg: state.status === 'qr' && state.qr ? qrToSvg(state.qr) : null,
    pairing: {
      number: p.number || '',
      code: state.status === 'connected' ? '' : p.code || '',
      ageSec: p.at ? Math.floor((Date.now() - p.at) / 1000) : null,
      error: p.error || '',
      pending: !!p.pending,
    },
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 2000) {
        reject(new Error('body terlalu besar'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, {
    'content-type': type,
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'content-security-policy': "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:",
  });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function createServer(controls) {
  return http.createServer(async (req, res) => {
    try {
      const url = (req.url || '/').split('?')[0];
      if (req.method === 'GET' && url === '/') return send(res, 200, PAGE, 'text/html; charset=utf-8');
      if (req.method === 'GET' && url === '/api/status') return send(res, 200, snapshot());
      if (req.method === 'POST') {
        // Header kustom ini tidak bisa dikirim situs lain lewat browser, jadi mencegah serangan CSRF ke localhost.
        if (req.headers['x-requested-with'] !== 'bot') return send(res, 403, { ok: false, error: 'Ditolak.' });
        const body = await readBody(req);
        if (url === '/api/pair') return send(res, 200, await controls.setPairingNumber(body.number));
        if (url === '/api/key') return send(res, 200, await saveKey(body));
        if (url === '/api/key/delete') return send(res, 200, deleteKey(body));
        if (url === '/api/restart') {
          controls.restart('dari halaman web').catch(() => {});
          return send(res, 200, { ok: true });
        }
        if (url === '/api/reset') {
          controls.resetSession().catch(() => {});
          return send(res, 200, { ok: true });
        }
      }
      send(res, 404, { ok: false, error: 'Tidak ditemukan.' });
    } catch (e) {
      send(res, 500, { ok: false, error: e.message });
    }
  });
}

function listen(server, host, port) {
  return new Promise((resolve) => {
    const onError = (e) => {
      server.off('listening', onListening);
      resolve(e.code === 'EADDRINUSE' ? 'busy' : null);
    };
    const onListening = () => {
      server.off('error', onError);
      resolve(port);
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port, host);
  });
}

/** Jalankan halaman web. Gagal (mis. port terpakai) tidak pernah menghentikan bot. */
async function startWebServer(controls) {
  if (process.env.WEB_ENABLED === 'false') return null;
  const host = process.env.WEB_HOST || '127.0.0.1';
  const first = Number(process.env.WEB_PORT) || 3000;
  for (let port = first; port < first + 10; port++) {
    const server = createServer(controls);
    const result = await listen(server, host, port);
    if (result === port) {
      server.on('error', (e) => console.error('[web]', e.message));
      console.log(`🌐 Halaman QR / kode pairing: http://localhost:${port}${QRCode ? '' : ' (gambar QR tidak tersedia, pakai QR di terminal)'}`);
      if (process.env.CODESPACES) console.log('   Di Codespaces: buka tab PORTS lalu klik ikon globe di port ' + port + '.');
      if (host !== '127.0.0.1' && host !== 'localhost') {
        console.warn('⚠️ WEB_HOST bukan localhost: siapa pun yang bisa mengakses alamat ini dapat menautkan WhatsApp bot.');
      }
      return server;
    }
    if (result !== 'busy') break;
  }
  console.warn('⚠️ Halaman web tidak bisa dijalankan (port terpakai). Bot tetap jalan; pakai QR / kode di terminal.');
  return null;
}

module.exports = { startWebServer, qrToSvg };
