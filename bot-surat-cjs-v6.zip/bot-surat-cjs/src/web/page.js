// Halaman kontrol koneksi WhatsApp (HTML statis; data diambil dari /api/status tiap 2 detik).
module.exports = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bot Surat - Koneksi WhatsApp</title>
<style>
  :root { color-scheme: light dark; --bg:#f6f7f9; --card:#fff; --fg:#1b1f24; --muted:#667085; --line:#e4e7ec; --ok:#12805c; --warn:#b54708; --bad:#b42318; --brand:#0b6bcb; }
  @media (prefers-color-scheme: dark) { :root { --bg:#14171c; --card:#1d2128; --fg:#eef0f3; --muted:#9aa3b2; --line:#2c323c; --ok:#4ac99b; --warn:#f0a64d; --bad:#f2837a; --brand:#6aa8f0; } }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--fg); font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
  main { max-width:460px; margin:0 auto; padding:20px 16px 40px; }
  h1 { font-size:1.25rem; margin:0 0 12px; }
  h2 { font-size:1rem; margin:0 0 10px; }
  section { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:16px; margin-top:14px; }
  .badge { display:inline-block; padding:4px 12px; border-radius:999px; font-weight:600; font-size:.9rem; border:1px solid var(--line); background:var(--card); }
  .badge.connected { color:var(--ok); } .badge.qr { color:var(--brand); }
  .badge.reconnecting, .badge.connecting, .badge.resetting, .badge.starting { color:var(--warn); }
  .badge.offline, .badge.replaced { color:var(--bad); }
  .muted { color:var(--muted); font-size:.9rem; margin:8px 0 0; }
  #qr svg { display:block; width:100%; max-width:300px; margin:0 auto; border-radius:8px; }
  #code { font:700 2rem/1.2 ui-monospace,Menlo,Consolas,monospace; letter-spacing:.12em; text-align:center; padding:14px 8px; margin-top:12px; border:2px dashed var(--brand); border-radius:10px; user-select:all; }
  form { display:flex; gap:8px; }
  input { flex:1; min-width:0; padding:10px 12px; font-size:1rem; border:1px solid var(--line); border-radius:8px; background:var(--bg); color:var(--fg); }
  button { padding:10px 14px; font-size:.95rem; border-radius:8px; border:1px solid var(--line); background:var(--card); color:var(--fg); cursor:pointer; }
  form button { background:var(--brand); border-color:var(--brand); color:#fff; font-weight:600; }
  button.danger { color:var(--bad); }
  .row { display:flex; gap:8px; flex-wrap:wrap; }
  .keyrow { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:8px 0; border-top:1px solid var(--line); }
  .keyrow:first-of-type { border-top:0; }
  .keyrow .st { font-size:.9rem; }
  .ok { color:var(--ok); } .no { color:var(--muted); } .err { color:var(--bad); }
  button.small { padding:6px 10px; font-size:.85rem; }
  .check { display:flex; align-items:center; gap:6px; margin-top:8px; font-size:.9rem; color:var(--muted); }
  .check input { flex:none; width:auto; }
  [hidden] { display:none !important; }
</style>
</head>
<body>
<main>
  <h1>Bot Surat &middot; WhatsApp</h1>
  <span id="badge" class="badge">Memuat...</span>
  <p id="note" class="muted"></p>

  <section id="qrBox" hidden>
    <h2>Scan QR</h2>
    <div id="qr"></div>
    <p class="muted">Di HP: WhatsApp &gt; Perangkat tertaut &gt; Tautkan perangkat. QR berganti otomatis.</p>
  </section>

  <section id="keyBox">
    <h2>API key AI</h2>
    <div id="keyList"></div>
    <form id="keyForm" style="margin-top:10px">
      <input id="keyInput" type="password" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Tempel API key (AIza... / sk-...)">
      <button type="submit">Simpan</button>
    </form>
    <label class="check"><input id="keyShow" type="checkbox"> Tampilkan key yang diketik</label>
    <p id="keyMsg" class="muted">Gemini diawali <b>AIza</b>, OpenAI diawali <b>sk-</b>; penyedia dikenali otomatis. Key tersimpan di komputer/Codespace bot (data/keys.json), tidak dikirim ke tempat lain selain penyedia AI-nya.</p>
  </section>

  <section id="pairBox">
    <h2>Atau pakai kode pairing</h2>
    <form id="pairForm">
      <input id="num" inputmode="numeric" autocomplete="off" placeholder="Nomor bot, mis. 628123456789">
      <button type="submit">Minta kode</button>
    </form>
    <div id="code" hidden></div>
    <p id="pairMsg" class="muted">Di HP: WhatsApp &gt; Perangkat tertaut &gt; Tautkan perangkat &gt; Tautkan dengan nomor telepon saja.</p>
  </section>

  <section>
    <h2>Kontrol</h2>
    <div class="row">
      <button id="btnRestart" type="button">Mulai ulang koneksi</button>
      <button id="btnReset" type="button" class="danger">Reset sesi</button>
    </div>
    <p class="muted">Reset sesi menghapus tautan lama; HP harus menautkan ulang lewat QR atau kode.</p>
  </section>
</main>
<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var lastSvg = '';
  function api(path, body) {
    var opt = body === undefined ? {} : { method: 'POST', headers: { 'content-type': 'application/json', 'x-requested-with': 'bot' }, body: JSON.stringify(body) };
    return fetch(path, opt).then(function (r) { return r.json(); });
  }
  function renderKeys(ai) {
    if (!ai) return;
    var box = $('keyList'); box.innerHTML = '';
    ['gemini', 'openai'].forEach(function (name) {
      var p = ai.providers[name]; if (!p) return;
      var row = document.createElement('div'); row.className = 'keyrow';
      var st = document.createElement('span'); st.className = 'st';
      var label = p.label + (p.primary ? ' (utama)' : '');
      if (p.set) { st.className += ' ok'; st.textContent = label + ': terpasang ' + p.masked + (p.source === 'env' ? ' (dari .env/Secret)' : ''); }
      else { st.className += ' no'; st.textContent = label + ': belum diisi'; }
      row.appendChild(st);
      if (p.set && p.source === 'web') {
        var b = document.createElement('button'); b.type = 'button'; b.className = 'small danger'; b.textContent = 'Hapus';
        b.addEventListener('click', function () {
          if (confirm('Hapus key ' + p.label + '?')) api('/api/key/delete', { provider: name }).then(tick);
        });
        row.appendChild(b);
      }
      box.appendChild(row);
    });
    var any = ai.providers.gemini.set || ai.providers.openai.set;
    if (ai.disabledByEnv) { $('keyMsg').className = 'muted err'; $('keyMsg').textContent = 'AI dimatikan lewat USE_AI=false di .env, key tidak dipakai.'; }
    else if (!any) { $('keyMsg').className = 'muted err'; $('keyMsg').textContent = 'Belum ada key: bot hanya memakai Regex dan PDF scan tidak bisa dibaca. Tempel key di atas.'; }
  }
  function render(s) {
    renderKeys(s.ai);
    $('badge').textContent = s.label;
    $('badge').className = 'badge ' + s.status;
    $('note').textContent = s.user ? 'Terhubung sebagai ' + s.user : (s.note || '');
    $('qrBox').hidden = !s.qrSvg;
    if (s.qrSvg && s.qrSvg !== lastSvg) { $('qr').innerHTML = s.qrSvg; lastSvg = s.qrSvg; }
    $('pairBox').hidden = s.status === 'connected';
    var p = s.pairing || {};
    if (p.number && !$('num').value && document.activeElement !== $('num')) $('num').value = p.number;
    var msg = $('pairMsg');
    if (p.code) {
      $('code').hidden = false; $('code').textContent = p.code;
      var left = Math.max(0, 150 - (p.ageSec || 0));
      msg.textContent = 'Masukkan kode ini di HP. Diganti otomatis sekitar ' + left + ' detik lagi bila belum dipakai.';
    } else {
      $('code').hidden = true;
      if (p.pending) msg.textContent = 'Kode akan muncul otomatis begitu koneksi siap...';
      else if (p.error) msg.textContent = 'Kode gagal dibuat: ' + p.error + '. Pakai QR atau coba lagi.';
    }
  }
  function tick() {
    api('/api/status').then(render).catch(function () {
      $('badge').textContent = 'Server bot tidak terjangkau';
      $('badge').className = 'badge offline';
    });
  }
  $('keyShow').addEventListener('change', function () { $('keyInput').type = $('keyShow').checked ? 'text' : 'password'; });
  $('keyForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var key = $('keyInput').value;
    if (!key.trim()) { $('keyMsg').className = 'muted err'; $('keyMsg').textContent = 'Tempel key dulu.'; return; }
    $('keyMsg').className = 'muted'; $('keyMsg').textContent = 'Memeriksa dan menyimpan key...';
    api('/api/key', { key: key }).then(function (r) {
      if (r.ok) {
        $('keyInput').value = '';
        $('keyMsg').className = 'muted ok';
        $('keyMsg').textContent = 'Key ' + r.label + ' disimpan' + (r.verified ? ' dan terverifikasi.' : '. ' + (r.warning || ''));
      } else {
        $('keyMsg').className = 'muted err'; $('keyMsg').textContent = r.error || 'Gagal menyimpan key.';
      }
      tick();
    }).catch(function () { $('keyMsg').className = 'muted err'; $('keyMsg').textContent = 'Server bot tidak terjangkau.'; });
  });
  $('pairForm').addEventListener('submit', function (e) {
    e.preventDefault();
    $('pairMsg').textContent = 'Membuat kode...';
    api('/api/pair', { number: $('num').value }).then(function (r) {
      if (!r.ok) $('pairMsg').textContent = r.error || 'Gagal membuat kode.';
      tick();
    }).catch(function () { $('pairMsg').textContent = 'Server bot tidak terjangkau.'; });
  });
  $('btnRestart').addEventListener('click', function () { api('/api/restart', {}).then(tick); });
  $('btnReset').addEventListener('click', function () {
    if (confirm('Reset sesi? HP harus menautkan ulang lewat QR atau kode pairing.')) api('/api/reset', {}).then(tick);
  });
  setInterval(tick, 2000);
  tick();
})();
</script>
</body>
</html>`;
