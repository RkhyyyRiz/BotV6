require('dotenv').config();
const keyStore = require('./utils/keyStore');

const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);

// Penyedia utama (dicoba lebih dulu). Penyedia lain dipakai sebagai cadangan jika key-nya ada.
const aiProvider = (process.env.AI_PROVIDER || 'gemini').trim().toLowerCase() === 'openai' ? 'openai' : 'gemini';
// Key dari .env / Secret. Yang belum ada akan ditanyakan di terminal saat npm start (src/index.js).
const keys = {
  gemini: process.env.GEMINI_API_KEY || '',
  openai: process.env.OPENAI_API_KEY || '',
};
// AI_API_KEY (umum, lama) dianggap key penyedia utama.
if (process.env.AI_API_KEY) keys[aiProvider] = process.env.AI_API_KEY;
// Key dari .env / Secret, dipakai lagi bila key yang diisi lewat web dihapus.
const envKeys = { ...keys };
// Key yang diisi lewat halaman web / terminal (data/keys.json) menimpa key dari .env.
Object.assign(keys, keyStore.read());

// Model bawaan, dicoba berurutan: bila model pertama tidak tersedia/kuota habis, bot beralih ke berikutnya.
const DEFAULT_MODELS = {
  gemini: ['gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.5-flash'],
  openai: ['gpt-6.1-terra', 'gpt-5.6-terra', 'gpt-5.4-mini'],
};
const sharedModels = list(process.env.AI_MODEL); // boleh campur nama Gemini & OpenAI, dipilah otomatis
const aiBaseUrl = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
function modelsFor(name) {
  const own = list(process.env[`${name.toUpperCase()}_MODEL`]);
  if (own.length) return own;
  const pick = sharedModels.filter((m) =>
    name === 'openai'
      ? process.env.AI_BASE_URL
        ? !/^gemini/i.test(m) // layanan kompatibel OpenAI (mis. OpenRouter): nama model bebas
        : /^(gpt|o\d|chatgpt)/i.test(m)
      : /^gemini/i.test(m)
  );
  return pick.length ? pick : DEFAULT_MODELS[name];
}
const models = { gemini: modelsFor('gemini'), openai: modelsFor('openai') };

/** Penyedia yang key-nya tersedia, urut: penyedia utama dulu, lalu cadangan. Dibaca ulang tiap dipanggil. */
function activeProviders() {
  const order = [aiProvider, aiProvider === 'openai' ? 'gemini' : 'openai'];
  return order.filter((n) => config.keys[n]).map((n) => ({ name: n, key: config.keys[n], models: models[n] }));
}

const config = {
  authDir: './auth_info',
  dataDir: './data',
  recapFiles: {
    masuk: './data/rekap_surat_masuk.xlsx',
    keluar: './data/rekap_surat_keluar.xlsx',
  },
  // Kop surat milik instansi sendiri => surat KELUAR; kop lain => surat MASUK.
  // Format: grup dipisah "|", kata kunci dalam satu grup dipisah ";" (semua harus ada di kop).
  ownKop: (
    process.env.OWN_KOP ||
    'KOTA BANJARMASIN;PERENCANAAN PEMBANGUNAN DAERAH;PENELITIAN|KOTA BANJARMASIN;BAPPEDA;LITBANG'
  )
    .split('|')
    .map((g) => g.split(';').map((k) => k.trim().toUpperCase()).filter(Boolean))
    .filter((g) => g.length),
  allowedNumbers: list(process.env.ALLOWED_NUMBERS),
  allowGroups: process.env.ALLOW_GROUPS === 'true',
  // Penyedia AI: 'gemini' dan/atau 'openai' (juga layanan kompatibel OpenAI lewat AI_BASE_URL).
  aiProvider,
  keys,
  envKeys,
  models,
  activeProviders,
  // Dibaca ulang tiap dipakai: key bisa ditambah/dihapus lewat halaman web tanpa memulai ulang bot.
  get useAI() {
    return process.env.USE_AI !== 'false' && activeProviders().length > 0;
  },
  aiBaseUrl,
  // Tingkat berpikir/penalaran: minimal/low/medium/high. Kosongkan (AI_THINKING=) untuk tidak mengirim.
  aiThinking: process.env.AI_THINKING === undefined ? 'low' : process.env.AI_THINKING.trim(),
  aiRetryMs: Number(process.env.AI_RETRY_MS) || 2000,
  minTextLength: 50, // di bawah ini dianggap PDF hasil scan
};

module.exports = { config };
