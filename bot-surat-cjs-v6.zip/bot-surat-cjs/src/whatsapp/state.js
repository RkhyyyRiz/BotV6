/** Status koneksi WhatsApp yang dipakai bersama oleh client.js (menulis) dan halaman web (membaca). */
const LABELS = {
  starting: 'Memulai',
  connecting: 'Menyambung',
  qr: 'Menunggu scan QR / kode pairing',
  connected: 'Terhubung',
  reconnecting: 'Menyambung ulang',
  resetting: 'Menyiapkan sesi baru',
  replaced: 'Sesi dipakai perangkat/proses lain',
  offline: 'Terputus',
};

const state = {
  status: 'starting',
  since: Date.now(), // kapan status terakhir berubah
  qr: null,
  qrAt: 0,
  pairing: { number: '', code: '', at: 0, error: '', pending: false },
  user: null,
  retry: 0,
  note: '',
};

// Socket WhatsApp yang sedang aktif (berganti tiap sambung ulang). Handler selalu memakai yang terbaru.
let currentSock = null;
const getSock = () => currentSock;
const setSock = (s) => {
  currentSock = s;
};

function set(patch) {
  if (patch.status && patch.status !== state.status) state.since = Date.now();
  Object.assign(state, patch);
}

module.exports = { state, set, LABELS, getSock, setSock };
