/**
 * Buku catatan pesan (data/inbox.json): menjaga agar pesan yang masuk saat bot mati/putus tetap dibalas.
 *  - pending : pesan yang sudah diterima tetapi belum selesai dibalas (disimpan utuh agar PDF-nya bisa diunduh ulang
 *              setelah bot dijalankan lagi).
 *  - done    : id pesan yang sudah selesai, supaya pesan yang dikirim ulang WhatsApp tidak dibalas dua kali.
 */
const fs = require('node:fs');
const path = require('node:path');
const { BufferJSON } = require('@whiskeysockets/baileys');

const FILE = path.join('./data', 'inbox.json');
const DONE_KEEP_MS = 7 * 24 * 3600 * 1000;
const DONE_MAX = 5000;

let db = null;

function load() {
  if (db) return db;
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'), BufferJSON.reviver);
    db = { pending: raw.pending || {}, done: raw.done || {} };
  } catch {
    db = { pending: {}, done: {} };
  }
  return db;
}

function save() {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    const tmp = `${FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(db, BufferJSON.replacer));
    fs.renameSync(tmp, FILE);
  } catch (e) {
    console.error('[inbox] gagal menyimpan:', e.message);
  }
}

const keyOf = (msg) => `${msg.key.remoteJid}|${msg.key.id}`;

const isDone = (k) => !!load().done[k];

function add(k, msg) {
  const d = load();
  if (!d.pending[k]) {
    d.pending[k] = { t: Date.now(), tries: 0, msg };
    save();
  }
}

/** Catat satu percobaan memproses; mengembalikan jumlah percobaan sejauh ini. */
function bump(k) {
  const e = load().pending[k];
  if (!e) return 1;
  e.tries = (e.tries || 0) + 1;
  save();
  return e.tries;
}

function finish(k) {
  const d = load();
  delete d.pending[k];
  d.done[k] = Date.now();
  const now = Date.now();
  const keys = Object.keys(d.done);
  for (const key of keys) if (now - d.done[key] > DONE_KEEP_MS) delete d.done[key];
  const left = Object.keys(d.done);
  if (left.length > DONE_MAX) {
    left.sort((a, b) => d.done[a] - d.done[b]).slice(0, left.length - DONE_MAX).forEach((key) => delete d.done[key]);
  }
  save();
}

const pending = () => Object.entries(load().pending);

module.exports = { keyOf, isDone, add, bump, finish, pending };
