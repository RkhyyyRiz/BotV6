const fs = require('node:fs');
const pino = require('pino');
const { downloadMediaMessage, normalizeMessageContent } = require('@whiskeysockets/baileys');
const { config } = require('../config');
const { extractTextFromPdf } = require('../services/pdfExtractor');
const { parseLetter } = require('../services/parser');
const { parseWithAI, parseScanWithAI } = require('../services/aiParser');
const { appendToRecap } = require('../services/recap');
const { formatTranscript, findMissing, mergeFields, TITLE } = require('../utils/format');
const { detectJenis } = require('../utils/jenis');
const { state, getSock } = require('./state');
const inbox = require('./inbox');

const logger = pino({ level: 'silent' });
const MAX_SCAN_BYTES = 10 * 1024 * 1024;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Pesan yang menumpuk saat bot offline dibalas bila umurnya tidak lebih dari ini (jam). 0 = jangan balas pesan lama.
const OFFLINE_HOURS = process.env.OFFLINE_REPLY_HOURS === undefined ? 48 : Number(process.env.OFFLINE_REPLY_HOURS) || 0;
const LATE_NOTICE_SEC = 120; // pesan lebih tua dari ini dibalas dengan catatan "bot sempat offline"
const MAX_TRIES = 3; // batas percobaan per pesan agar pesan bermasalah tidak diulang terus
const WAIT_CONNECTED_MS = 5 * 60000;

let queue = Promise.resolve(); // proses satu per satu agar file Excel tidak bentrok
const active = new Set(); // pesan yang sedang antre / diproses

/** ".rekap", ".rekap keluar", ".bantuan" (awalan "." atau "!"). */
function parseCommand(text) {
  const m = (text || '').trim().toLowerCase().match(/^[.!]([a-z]+)(?:\s+(.*))?$/);
  return m ? { cmd: m[1], arg: (m[2] || '').trim() } : null;
}
const jenisOf = (x) => (x === 'masuk' || x === 'keluar' ? x : null);

const senderNumber = (msg) =>
  (msg.key.participant || msg.key.remoteJid || '').split('@')[0].split(':')[0];

/** Nomor (digit saja) milik bot sendiri: bentuk nomor telepon dan bentuk LID. */
function ownNumbers() {
  const u = getSock()?.user;
  const strip = (j) => String(j || '').split('@')[0].split(':')[0];
  return [strip(u?.id), strip(u?.lid), strip(state.user)].filter(Boolean);
}

/** Pesan dari nomor bot sendiri ke chat nomor bot sendiri ("Pesan ke diri sendiri"). */
function isSelfChat(msg) {
  if (!msg?.key?.fromMe) return false;
  const jid = msg.key.remoteJid || '';
  if (!jid || jid.endsWith('@g.us') || jid === 'status@broadcast') return false;
  return ownNumbers().includes(jid.split('@')[0].split(':')[0]);
}

// ID pesan yang dikirim bot sendiri (balasan), supaya di chat sendiri tidak diproses ulang.
const sentIds = new Set();
function rememberSent(res) {
  const id = res?.key?.id;
  if (!id) return;
  sentIds.add(id);
  if (sentIds.size > 500) sentIds.delete(sentIds.values().next().value);
}

function isAllowed(msg) {
  if (isSelfChat(msg)) return true; // nomor sendiri selalu diizinkan
  if (config.allowedNumbers.length === 0) return true;
  return config.allowedNumbers.includes(senderNumber(msg));
}

const isPdfDoc = (doc) =>
  !!doc && (doc.mimetype === 'application/pdf' || (doc.fileName || '').toLowerCase().endsWith('.pdf'));

/** Deteksi dokumen PDF, termasuk yang diteruskan (forward) atau memakai caption. */
function getPdfDocument(msg) {
  const doc = normalizeMessageContent(msg.message)?.documentMessage;
  return isPdfDoc(doc) ? doc : null;
}

function getText(msg) {
  const c = normalizeMessageContent(msg.message);
  return (c?.conversation || c?.extendedTextMessage?.text || '').trim();
}

/** Waktu pesan (detik) dari angka, string, atau objek Long (juga yang sudah lewat JSON). */
function tsSeconds(t) {
  if (t == null) return null;
  if (typeof t === 'number') return t;
  if (typeof t === 'string') return Number(t) || null;
  if (typeof t.toNumber === 'function') return t.toNumber();
  if (typeof t.low === 'number') return (t.high >>> 0) * 4294967296 + (t.low >>> 0);
  return null;
}
function ageSec(msg) {
  const t = tsSeconds(msg.messageTimestamp);
  return t ? Math.max(0, Date.now() / 1000 - t) : null;
}

const HELP =
  '*Bot Surat*\n\n' +
  'Teruskan (forward) file PDF surat, bot menganalisis sendiri apakah *surat masuk* atau *surat keluar*, lalu mengirim balik isian untuk e-office dan mencatatnya ke rekap.\n\n' +
  '*Perintah*\n' +
  '• *.rekap* : kirim rekap Excel masuk & keluar\n' +
  '• *.rekap masuk* / *.rekap keluar* : salah satunya\n' +
  '• *.bantuan* : bantuan ini';

/** Pesan yang perlu ditangani bot: PDF atau perintah, dari pengirim yang diizinkan. */
function worthHandling(msg) {
  if (!msg?.message) return false;
  if (msg.key.fromMe && !isSelfChat(msg)) return false; // pesan keluar ke orang lain diabaikan
  if (sentIds.has(msg.key.id)) return false; // balasan bot sendiri
  const jid = msg.key.remoteJid;
  if (!jid || jid === 'status@broadcast') return false;
  if (jid.endsWith('@g.us') && !config.allowGroups) return false;
  if (!isAllowed(msg)) return false;
  return !!getPdfDocument(msg) || !!parseCommand(getText(msg));
}

async function waitConnected(ms) {
  const end = Date.now() + ms;
  while (state.status !== 'connected' || !getSock()) {
    if (Date.now() > end) return false;
    await sleep(1000);
  }
  return true;
}

/** Kirim pesan; bila koneksi sedang putus, tunggu tersambung lalu coba sekali lagi. */
async function deliver(jid, content, quoted) {
  const send = () => {
    const s = getSock();
    if (!s) throw new Error('WhatsApp belum tersambung');
    return s.sendMessage(jid, content, { quoted });
  };
  try {
    const res = await send();
    rememberSent(res);
    return res;
  } catch (e) {
    if (!(await waitConnected(2 * 60000))) throw e;
    const res = await send();
    rememberSent(res);
    return res;
  }
}

/**
 * Terima pesan dari WhatsApp. meta.type: 'notify' (baru) / 'append' (menumpuk saat offline);
 * meta.recovered: dipulihkan dari buku catatan setelah bot dijalankan lagi.
 */
function handleMessage(sock, msg, meta = {}) {
  if (!worthHandling(msg)) return Promise.resolve();
  const k = inbox.keyOf(msg);
  if (inbox.isDone(k) || active.has(k)) return Promise.resolve();

  const age = ageSec(msg);
  const delayed = meta.type === 'append' || (age !== null && age > LATE_NOTICE_SEC);
  if (delayed) {
    const tooOld = OFFLINE_HOURS <= 0 ? !meta.recovered : age !== null && age > OFFLINE_HOURS * 3600;
    if (tooOld) {
      console.log(`⏭️ Pesan lama dilewati (${age === null ? 'umur tidak diketahui' : `${Math.round(age / 3600)} jam`}, batas OFFLINE_REPLY_HOURS=${OFFLINE_HOURS}).`);
      return Promise.resolve();
    }
  }

  active.add(k);
  inbox.add(k, msg); // dicatat dulu: bila bot mati sebelum selesai, dilanjutkan saat tersambung lagi
  if (delayed || meta.recovered) console.log(`📥 Pesan tertunda diproses: ${senderNumber(msg)}`);
  queue = queue
    .then(() => run(k, msg, delayed || !!meta.recovered))
    .catch((e) => console.error('[queue]', e))
    .finally(() => active.delete(k));
  return queue;
}

async function run(k, msg, late) {
  // Tunggu koneksi; bila tidak kunjung tersambung, pesan tetap tercatat dan dilanjutkan saat tersambung lagi.
  if (!(await waitConnected(WAIT_CONNECTED_MS))) return;
  if (inbox.bump(k) > MAX_TRIES) {
    console.warn('⚠️ Pesan dilewati: gagal diproses beberapa kali.');
    return inbox.finish(k);
  }
  try {
    await processMessage(msg, late);
    inbox.finish(k);
  } catch (e) {
    console.error('[proses tertunda, dicoba lagi saat tersambung]', e.message);
  }
}

/** Dipanggil tiap WhatsApp tersambung: lanjutkan pesan yang belum sempat dibalas. */
function recoverPending(sock) {
  const items = inbox.pending();
  if (!items.length) return;
  console.log(`📥 Melanjutkan ${items.length} pesan yang belum sempat dibalas...`);
  for (const [, entry] of items) handleMessage(sock, entry.msg, { recovered: true });
}

async function processMessage(msg, late) {
  const jid = msg.key.remoteJid;
  const sender = senderNumber(msg);
  let notice = late;
  const reply = async (text) => {
    const body = notice ? `🕘 _Bot sempat offline, pesan ini baru dibalas sekarang._\n${text}` : text;
    const res = await deliver(jid, { text: body }, msg);
    notice = false;
    return res;
  };

  // ---- Dokumen PDF (forward / kirim langsung) ----
  const doc = getPdfDocument(msg);
  if (doc) return processPdf({ msg, doc, jid, reply, sender });

  // ---- Perintah teks ----
  const cmd = parseCommand(getText(msg));
  if (!cmd) return;

  if (cmd.cmd === 'bantuan' || cmd.cmd === 'help') return reply(HELP);

  if (cmd.cmd === 'rekap') {
    const which = jenisOf(cmd.arg) ? [cmd.arg] : ['masuk', 'keluar'];
    let sent = 0;
    for (const j of which) {
      const file = config.recapFiles[j];
      if (!fs.existsSync(file)) continue;
      await deliver(
        jid,
        {
          document: fs.readFileSync(file),
          mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          fileName: `rekap_surat_${j}.xlsx`,
        },
        msg
      );
      sent++;
    }
    if (!sent) return reply('Rekap belum ada. Belum ada surat yang diproses.');
    return;
  }
}

async function processPdf({ msg, doc, jid, reply, sender }) {
  const fileName = doc.fileName || 'surat.pdf';
  await reply(`⏳ Memproses *${fileName}* ...`);

  try {
    const buffer = await downloadMediaMessage(
      msg,
      'buffer',
      {},
      { logger, reuploadRequest: (m) => getSock().updateMediaMessage(m) }
    );

    const rawText = await extractTextFromPdf(buffer);
    const isScan = rawText.trim().length < config.minTextLength;
    let data;
    let scanNote = '';
    let aiNote = ''; // catatan jika AI gagal pada PDF digital
    const kops = []; // kop surat yang terbaca, dipakai menentukan surat masuk / keluar

    if (isScan) {
      // PDF scan: tidak ada teks, Gemini membaca gambarnya langsung.
      if (!config.useAI) {
        return reply(
          '⚠️ PDF ini hasil *scan* (berupa gambar). Aktifkan AI (USE_AI=true dan API key AI) agar scan bisa dibaca, atau isi manual.'
        );
      }
      if (buffer.length > MAX_SCAN_BYTES) {
        return reply('⚠️ PDF scan terlalu besar (maks. 10 MB). Kecilkan ukurannya atau isi manual.');
      }
      try {
        const aiData = await parseScanWithAI(buffer);
        kops.push(aiData.pengirim);
        data = mergeFields(aiData, null);
        scanNote = '\n📷 PDF scan dibaca dengan AI, *mohon cek ulang* isiannya sebelum disalin ke e-office.';
      } catch (e) {
        console.error('[AI scan gagal]', e.message);
        return reply('⚠️ PDF scan gagal dibaca AI: ' + e.message.slice(0, 120) + '\nSilakan isi manual.');
      }
    } else {
      // Regex selalu jalan; AI (jika aktif) menjadi sumber utama, Regex mengisi yang kosong.
      const regexData = parseLetter(rawText);
      kops.push(regexData.pengirim);
      data = regexData;
      if (config.useAI) {
        try {
          const aiData = await parseWithAI(rawText);
          kops.push(aiData.pengirim);
          data = mergeFields(aiData, regexData);
        } catch (e) {
          console.error('[AI parser gagal, pakai Regex]', e.message);
          aiNote = '\n⚠️ AI gagal membaca surat, hasil di atas dari Regex saja. *Mohon cek ulang* isiannya.';
        }
      }
    }

    // PDF TTE/bercap kadang punya sedikit teks tersembunyi sehingga tidak terdeteksi scan.
    // Jika nomor & perihal sama-sama kosong, baca ulang gambarnya dengan AI.
    if (!isScan && config.useAI && !data.nomor && !data.perihal && buffer.length <= MAX_SCAN_BYTES) {
      try {
        const aiData = await parseScanWithAI(buffer);
        kops.push(aiData.pengirim);
        data = mergeFields(aiData, data);
        scanNote = '\n📷 Teks PDF tidak terbaca normal, dibaca dengan AI, *mohon cek ulang* isiannya.';
      } catch (e) {
        console.error('[AI scan fallback gagal]', e.message);
        aiNote = aiNote || '\n⚠️ AI gagal membaca ulang surat ini. *Mohon cek ulang* isiannya.';
      }
    }

    // Kop = instansi sendiri => surat keluar; selain itu surat masuk.
    const jenis = detectJenis(...kops);
    console.log(`[jenis] ${fileName} -> ${jenis} (kop: ${kops.filter(Boolean).join(' | ') || '-'})`);

    const missing = findMissing(data, jenis);
    let note = '';
    try {
      const res = appendToRecap(
        { ...data, namaFile: fileName, diprosesOleh: msg.pushName || sender },
        jenis
      );
      note = res.duplicate
        ? `\n♻️ Surat dengan nomor yang sama sudah ada di rekap ${jenis} (No. ${res.row}), tidak dicatat ulang.`
        : `\n🗂️ Tercatat di rekap ${jenis} (No. ${res.row}).`;
    } catch (e) {
      console.error('[rekap]', e);
      note =
        '\n⚠️ Gagal mencatat ke rekap. Jika file Excel sedang terbuka, tutup dulu lalu kirim ulang PDF-nya.';
    }

    await reply(formatTranscript(data, missing, jenis) + scanNote + aiNote + note);
  } catch (e) {
    console.error('[proses PDF]', e);
    await reply('❌ Gagal memproses PDF: ' + e.message);
  }
}

module.exports = { handleMessage, recoverPending, getPdfDocument };
