const fs = require('node:fs');
const path = require('node:path');
const baileys = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');
const pino = require('pino');
const { config } = require('../config');
const { state, set, setSock } = require('./state');
const { normalizeNumber } = require('../utils/phone');

const makeWASocket = baileys.default || baileys;
const { useMultiFileAuthState, fetchLatestBaileysVersion, Browsers } = baileys;

// Kode putus koneksi WhatsApp (ditulis sendiri agar tidak bergantung pada versi Baileys).
const CODE = { loggedOut: 401, forbidden: 403, timedOut: 408, multideviceMismatch: 411, replaced: 440, badSession: 500, restartRequired: 515 };

const PAIRING_REFRESH_MS = 150000; // kode pairing dibuat ulang tiap 2,5 menit selama belum tertaut
const PAIRING_AUTO_MAX = 8; // batas permintaan otomatis agar tidak dibatasi WhatsApp
const WATCHDOG_MS = 30000;
const STUCK_MS = 180000; // macet "menyambung" selama ini -> koneksi di-reset
const MAX_BACKOFF_MS = 60000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(...a);

let onMessageRef = null;
let onOpenRef = null;
let sock = null;
let generation = 0; // naik tiap socket baru; event dari socket lama diabaikan
let starting = false;
let startAgain = false;
let reconnectTimer = null;
let retry = 0;
let badSessionCount = 0;
let resetTimes = [];
let pairingNumber = '';
let pairingTimer = null;
let pairingRequests = 0;
let pairingBusy = false;
let readyForPairing = false; // socket sudah menerima QR pertama (artinya siap meminta kode)
let watchdog = null;

// ---------- sesi (folder auth) ----------

const credsPath = () => path.join(config.authDir, 'creds.json');

function moveAuthToBackup() {
  const bak = `${config.authDir}.bak`;
  try {
    fs.rmSync(bak, { recursive: true, force: true });
    fs.renameSync(config.authDir, bak);
  } catch {
    fs.rmSync(config.authDir, { recursive: true, force: true });
  }
}

/** File sesi setengah tertulis/rusak dipindah ke cadangan supaya tidak membuat Baileys error terus. */
function checkAuthDir() {
  fs.mkdirSync(config.authDir, { recursive: true });
  if (!fs.existsSync(credsPath())) return;
  try {
    JSON.parse(fs.readFileSync(credsPath(), 'utf8'));
  } catch {
    log('⚠️ File sesi rusak, dipindah ke cadangan. Perlu scan QR / pairing ulang.');
    moveAuthToBackup();
    fs.mkdirSync(config.authDir, { recursive: true });
  }
}

/** Cek ringan sebelum menyambung. Hanya memberi peringatan, tidak pernah menghentikan bot. */
function preflight() {
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 20) console.warn(`⚠️ Node ${process.versions.node} terlalu lama, pakai Node 20 ke atas.`);
  try {
    fs.mkdirSync(config.authDir, { recursive: true });
    fs.accessSync(config.authDir, fs.constants.W_OK);
  } catch (e) {
    console.error(`❌ Folder sesi (${config.authDir}) tidak bisa ditulis: ${e.message}`);
  }
  checkAuthDir();
  // Cek jaringan berjalan di latar belakang agar tidak menunda start.
  fetch('https://web.whatsapp.com/', { method: 'HEAD', signal: AbortSignal.timeout(8000) }).catch((e) =>
    console.warn(`⚠️ Server WhatsApp belum terjangkau dari jaringan ini (${e.cause?.code || e.message}). Cek internet/firewall.`)
  );
}

// ---------- tampilan di terminal ----------

function printQr(qr) {
  log('\nScan QR berikut lewat WhatsApp > Perangkat tertaut > Tautkan perangkat (atau pakai kode pairing / halaman web):\n');
  qrcode.generate(qr, { small: true });
}

function printPairing(code) {
  const line = `  KODE PAIRING:  ${code}  `;
  const bar = '═'.repeat(line.length);
  log(`\n╔${bar}╗\n║${line}║\n╚${bar}╝`);
  log(`Nomor ${pairingNumber}. Di HP: WhatsApp > Perangkat tertaut > Tautkan perangkat > "Tautkan dengan nomor telepon saja", lalu masukkan kode di atas.\n`);
}

// ---------- socket ----------

async function teardown() {
  if (!sock) return;
  const old = sock;
  sock = null;
  setSock(null);
  readyForPairing = false;
  try {
    old.ev.removeAllListeners();
  } catch {}
  try {
    old.end(undefined);
  } catch {}
  try {
    old.ws?.close();
  } catch {}
}

async function connect(reason) {
  if (starting) {
    startAgain = true;
    return;
  }
  starting = true;
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  clearInterval(pairingTimer);
  pairingTimer = null;
  const gen = ++generation;
  try {
    await teardown();
    checkAuthDir();
    const { state: auth, saveCreds } = await useMultiFileAuthState(config.authDir);
    let version;
    try {
      ({ version } = await fetchLatestBaileysVersion());
    } catch {}
    const browser = Browsers?.ubuntu ? Browsers.ubuntu('Chrome') : ['Ubuntu', 'Chrome', '22.04.4'];
    const s = makeWASocket({
      version,
      auth,
      logger: pino({ level: 'silent' }),
      browser,
      syncFullHistory: false,
      markOnlineOnConnect: false,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 25000,
    });
    sock = s;
    setSock(s);
    set({ status: reason === 'awal' ? 'connecting' : 'reconnecting', qr: null });

    s.ev.on('creds.update', () => saveCreds().catch((e) => console.error('[wa] gagal menyimpan sesi:', e.message)));
    s.ev.on('connection.update', (u) => onUpdate(gen, s, u));
    // 'notify' = pesan baru saat bot online. 'append' = pesan yang menumpuk selama bot offline
    // (dikirim WhatsApp begitu tersambung). Keduanya diproses; handler menyaring yang terlalu lama / ganda.
    s.ev.on('messages.upsert', ({ messages, type }) => {
      if (gen !== generation || (type !== 'notify' && type !== 'append')) return;
      for (const msg of messages) {
        onMessageRef(s, msg, { type }).catch((e) => console.error('[handler]', e));
      }
    });
  } catch (e) {
    console.error('[wa] gagal membuat koneksi:', e.message);
    scheduleReconnect('gagal membuat koneksi');
  } finally {
    starting = false;
    if (startAgain) {
      startAgain = false;
      setImmediate(() => connect('ulang'));
    }
  }
}

function scheduleReconnect(why, fixedDelay, status = 'reconnecting') {
  if (reconnectTimer) return;
  let delay = fixedDelay;
  if (delay === undefined) {
    delay = Math.min(MAX_BACKOFF_MS, 2000 * 2 ** Math.min(retry, 5)) + Math.floor(Math.random() * 1000);
    retry++;
  }
  set({ status, retry, note: why });
  log(`🔁 ${why}. Menyambung ulang dalam ${Math.max(1, Math.round(delay / 1000))} detik${retry ? ` (percobaan ${retry})` : ''}...`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect('ulang');
  }, delay);
}

function onUpdate(gen, s, { connection, lastDisconnect, qr }) {
  if (gen !== generation) return;
  if (qr) onQr(gen, s, qr);
  if (connection === 'connecting' && state.status !== 'qr') set({ status: 'connecting' });
  if (connection === 'open') onOpen(s);
  if (connection === 'close') onClose(lastDisconnect);
}

function onOpen(s) {
  retry = 0;
  badSessionCount = 0;
  pairingRequests = 0;
  readyForPairing = false;
  clearInterval(pairingTimer);
  pairingTimer = null;
  const me = s.user?.id ? String(s.user.id).split(':')[0].split('@')[0] : null;
  set({
    status: 'connected',
    qr: null,
    user: me,
    retry: 0,
    note: '',
    pairing: { number: pairingNumber, code: '', at: 0, error: '', pending: false },
  });
  log(`✅ WhatsApp terhubung${me ? ` sebagai ${me}` : ''}. Bot siap menerima PDF.`);
  // Lanjutkan pesan yang belum sempat dibalas (bot mati/putus saat memproses).
  if (onOpenRef) setImmediate(() => Promise.resolve(onOpenRef(s)).catch((e) => console.error('[pulihkan]', e)));
}

function onClose(lastDisconnect) {
  const err = lastDisconnect?.error;
  const code = err?.output?.statusCode;
  const waitingLogin = state.status === 'qr';
  log(`⚠️ Koneksi terputus (kode ${code ?? '?'}${err?.message ? `: ${err.message}` : ''}).`);
  set({ status: 'offline' });

  if (code === CODE.loggedOut) return resetSession('perangkat dikeluarkan dari WhatsApp (logout)');
  if (code === CODE.badSession || code === CODE.multideviceMismatch) {
    badSessionCount++;
    if (badSessionCount >= 3) return resetSession('sesi rusak berulang');
    return scheduleReconnect('sesi bermasalah, mencoba lagi', 3000);
  }
  if (code === CODE.restartRequired) return scheduleReconnect('WhatsApp meminta restart koneksi (normal setelah tautan berhasil)', 500);
  if (code === CODE.replaced) {
    return scheduleReconnect('sesi dipakai perangkat/proses lain (pastikan hanya satu bot yang berjalan)', 30000, 'replaced');
  }
  if (code === CODE.forbidden) return scheduleReconnect('akses ditolak WhatsApp (403)', 60000);
  if (waitingLogin && code === CODE.timedOut) return scheduleReconnect('QR kedaluwarsa, membuat QR baru', 1500);
  return scheduleReconnect('koneksi terputus');
}

/** Hapus sesi (dicadangkan ke auth_info.bak) lalu siap tautkan ulang lewat QR / kode pairing. */
async function resetSession(reason) {
  const now = Date.now();
  resetTimes = resetTimes.filter((t) => now - t < 10 * 60000);
  resetTimes.push(now);
  log(`🔄 Reset sesi: ${reason}. Sesi lama dicadangkan, bot siap ditautkan ulang.`);
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  clearInterval(pairingTimer);
  pairingTimer = null;
  generation++; // abaikan event dari socket lama
  await teardown();
  moveAuthToBackup();
  retry = 0;
  badSessionCount = 0;
  pairingRequests = 0;
  set({
    status: 'resetting',
    qr: null,
    user: null,
    pairing: { number: pairingNumber, code: '', at: 0, error: '', pending: !!pairingNumber },
  });
  const delay = resetTimes.length >= 3 ? 300000 : 1500;
  if (delay > 1500) log('⏸️ Reset berulang, menunggu 5 menit sebelum mencoba lagi (menghindari pembatasan WhatsApp).');
  scheduleReconnect('menyiapkan sesi baru', delay, 'resetting');
}

function restart(reason = 'diminta') {
  log(`🔄 Memulai ulang koneksi (${reason})...`);
  clearTimeout(reconnectTimer);
  reconnectTimer = null;
  retry = 0;
  return connect('ulang');
}

// ---------- QR + kode pairing ----------

function onQr(gen, s, qr) {
  readyForPairing = true;
  set({ status: 'qr', qr, qrAt: Date.now() });
  printQr(qr);
  if (!pairingNumber || s.authState.creds.registered) return;
  if (!pairingTimer) ensurePairingTimer(gen, s);
  if (!state.pairing.code && !pairingBusy && pairingRequests < PAIRING_AUTO_MAX) requestPairing(gen, s, false);
}

function ensurePairingTimer(gen, s) {
  clearInterval(pairingTimer);
  pairingTimer = setInterval(() => {
    if (gen !== generation || state.status === 'connected' || !readyForPairing) {
      clearInterval(pairingTimer);
      pairingTimer = null;
      return;
    }
    if (pairingRequests < PAIRING_AUTO_MAX) requestPairing(gen, s, false);
  }, PAIRING_REFRESH_MS);
}

/** Minta kode pairing; mencoba 3x bila gagal. `manual` = diminta pengguna (tidak kena batas otomatis). */
async function requestPairing(gen, s, manual) {
  if (!pairingNumber) return { ok: false, error: 'Nomor belum diisi.' };
  if (s.authState.creds.registered) return { ok: false, error: 'Perangkat sudah tertaut.' };
  if (pairingBusy) return { ok: false, error: 'Sedang membuat kode, tunggu sebentar.' };
  pairingBusy = true;
  let lastError = '';
  try {
    for (let attempt = 1; attempt <= 3; attempt++) {
      if (gen !== generation) return { ok: false, error: 'Koneksi sedang diganti, coba lagi.' };
      try {
        pairingRequests++;
        const raw = await s.requestPairingCode(pairingNumber);
        const code = String(raw).replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        const pretty = code.length === 8 ? `${code.slice(0, 4)}-${code.slice(4)}` : code;
        set({ pairing: { number: pairingNumber, code: pretty, at: Date.now(), error: '', pending: false } });
        printPairing(pretty);
        return { ok: true, code: pretty };
      } catch (e) {
        lastError = e?.message || String(e);
        if (attempt < 3) await sleep(2000 * attempt);
      }
    }
    set({ pairing: { number: pairingNumber, code: '', at: 0, error: lastError, pending: false } });
    console.error(`⚠️ Kode pairing gagal dibuat (${lastError}). Pakai QR di atas atau coba lagi dari halaman web.`);
    return { ok: false, error: lastError };
  } finally {
    pairingBusy = false;
  }
}

/** Dipanggil dari halaman web: simpan nomor lalu buat kode (atau tunggu sampai koneksi siap). */
async function setPairingNumber(raw) {
  const n = normalizeNumber(raw);
  if (!n) return { ok: false, error: 'Nomor tidak valid. Contoh: 628123456789' };
  if (state.status === 'connected') {
    return { ok: false, error: 'Bot sudah terhubung. Reset sesi dulu bila ingin menautkan nomor lain.' };
  }
  pairingNumber = n;
  pairingRequests = 0;
  set({ pairing: { number: n, code: '', at: 0, error: '', pending: true } });
  if (sock && readyForPairing) {
    const r = await requestPairing(generation, sock, true);
    if (r.ok) ensurePairingTimer(generation, sock);
    return r;
  }
  return { ok: true, pending: true }; // otomatis dibuat begitu QR pertama muncul
}

// ---------- watchdog ----------

function startWatchdog() {
  if (watchdog) return;
  watchdog = setInterval(() => {
    const waiting = ['starting', 'connecting', 'reconnecting', 'offline'].includes(state.status);
    if (waiting && !reconnectTimer && !starting && Date.now() - state.since > STUCK_MS) {
      log('⏱️ Koneksi macet terlalu lama.');
      restart('watchdog');
    }
  }, WATCHDOG_MS);
  watchdog.unref();
}

function createWhatsApp(onMessage, { onOpen } = {}) {
  onMessageRef = onMessage;
  onOpenRef = onOpen || null;
  return {
    async start() {
      pairingNumber = normalizeNumber(process.env.PAIRING_NUMBER);
      if (pairingNumber) set({ pairing: { number: pairingNumber, code: '', at: 0, error: '', pending: true } });
      preflight();
      startWatchdog();
      await connect('awal');
    },
    restart,
    resetSession: () => resetSession('diminta pengguna'),
    setPairingNumber,
    hasPairingNumber: () => !!pairingNumber,
  };
}

module.exports = { createWhatsApp };
