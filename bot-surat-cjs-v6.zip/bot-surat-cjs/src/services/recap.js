const fs = require('node:fs');
const XLSX = require('xlsx');
const { config } = require('../config');
const { nowWIB } = require('../utils/date');
const { PARTY } = require('../utils/format');

const SHEET = { masuk: 'Rekap Surat Masuk', keluar: 'Rekap Surat Keluar' };

const colsFor = (jenis) => [
  'No', 'Waktu Diproses', 'Status Surat', 'Nomor Surat', 'Tanggal Surat', PARTY[jenis][1],
  'Perihal', 'Tanggal Acara', 'Jam Acara', 'Tempat Acara', 'Nama File', 'Diproses Oleh',
];

/** Tambah satu baris ke Excel surat masuk / keluar. Mengembalikan { duplicate, row }. */
function appendToRecap(rec, jenis = 'masuk') {
  const file = config.recapFiles[jenis];
  const sheet = SHEET[jenis];
  const cols = colsFor(jenis);
  const [partyKey, partyLabel] = PARTY[jenis];
  fs.mkdirSync(config.dataDir, { recursive: true });

  let rows = [];
  if (fs.existsSync(file)) {
    const wb = XLSX.readFile(file);
    rows = XLSX.utils.sheet_to_json(wb.Sheets[sheet] || wb.Sheets[wb.SheetNames[0]]);
  }

  if (rec.nomor) {
    const dup = rows.find((r) => String(r['Nomor Surat']).trim() === rec.nomor.trim());
    if (dup) return { duplicate: true, row: dup['No'] };
  }

  const no = rows.length + 1;
  rows.push({
    'No': no,
    'Waktu Diproses': nowWIB(),
    'Status Surat': rec.status || '-',
    'Nomor Surat': rec.nomor || '-',
    'Tanggal Surat': rec.tanggal || '-',
    [partyLabel]: rec[partyKey] || '-',
    'Perihal': rec.perihal || '-',
    'Tanggal Acara': rec.tanggalAcara || '-',
    'Jam Acara': rec.jamAcara || '-',
    'Tempat Acara': rec.tempat || '-',
    'Nama File': rec.namaFile || '-',
    'Diproses Oleh': rec.diprosesOleh || '-',
  });

  const ws = XLSX.utils.json_to_sheet(rows, { header: cols });
  ws['!cols'] = [6, 20, 12, 28, 14, 38, 50, 14, 22, 36, 30, 18].map((wch) => ({ wch }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheet);
  XLSX.writeFile(wb, file);

  return { duplicate: false, row: no };
}

module.exports = { appendToRecap };
