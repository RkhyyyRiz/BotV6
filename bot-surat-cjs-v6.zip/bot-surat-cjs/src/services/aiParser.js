const { config } = require('../config');
const { normalizeDate } = require('../utils/date');

const SYSTEM = `Kamu adalah asisten administrasi persuratan pemerintah daerah di Indonesia.
Dari surat yang diberikan, ekstrak data berikut dan balas HANYA dengan satu objek JSON, tanpa teks lain, tanpa markdown:
{
  "status": "Biasa" | "Undangan" | "Kunjungan",
  "nomor": string | null,
  "tanggal": string | null,
  "pengirim": string | null,
  "tujuan": string | null,
  "perihal": string | null,
  "tanggalAcara": string | null,
  "jamAcara": string | null,
  "tempat": string | null
}
Aturan:
- "status": "Undangan" jika surat mengundang rapat/acara/kegiatan; "Kunjungan" jika perihalnya kunjungan, audiensi, studi banding/tiru/lapangan; selain itu "Biasa".
- "nomor" = nomor surat lengkap persis seperti tertulis (contoh "900.1.2/123/Bappeda"), tanpa kata "Nomor". Nomor bisa berada di baris terpisah dari labelnya.
- "tanggal" = tanggal surat dibuat (biasanya di dekat kota penandatanganan, contoh "Banjarbaru, 11 November 2026"), format DD/MM/YYYY. Bukan tanggal acara.
- "tanggalAcara" format DD/MM/YYYY; jika rentang beberapa hari, tulis apa adanya (contoh "16-17/11/2026").
- "pengirim" = tulisan kop surat paling atas (nama instansi induk + unit/dinas), digabung dengan koma. Contoh kop "PEMERINTAH PROPINSI KALIMANTAN SELATAN" lalu "DINAS PERHUBUNGAN" -> "Pemerintah Propinsi Kalimantan Selatan, Dinas Perhubungan". Ambil SEMUA baris nama instansi di kop, tetapi JANGAN sertakan alamat, laman, pos-el, telepon, atau nama penandatangan. Tulis dengan huruf kapital di awal kata (Title Case), bukan semua huruf besar, dan pertahankan ejaan sesuai surat.
- "tujuan" = penerima surat, yaitu nama/jabatan setelah "Yth." atau "Kepada", beserta kota/lokasi setelah "di" jika disebut (abaikan "di Tempat"). Jika penerima lebih dari satu (bernomor), gabungkan dengan "; ". Jika berbunyi "Daftar Nama Terlampir/Daftar terlampir" tulis apa adanya. JANGAN mengambil kop surat maupun nama penandatangan.
- "perihal" = isi baris Perihal/Hal. JANGAN ikut menyertakan daftar penerima atau kalimat pembuka surat. Jika status "Undangan" dan isi Perihal hanya kata "Undangan" (atau sejenisnya), JANGAN tulis "Undangan": isi dengan tujuan acaranya, yaitu nama acara dari field "Acara" (contoh "Ekspose Laporan Pendahuluan"), atau jika tidak ada, ringkas kalimat yang diawali "dalam rangka" (contoh "Mendukung pekerjaan Penyusunan Masterplan Pengembangan Kawasan Sungai Peradaban").
- "jamAcara" contoh "09.00 WIB s.d. selesai".
- Surat biasa tanpa acara: tanggalAcara, jamAcara, tempat = null.
- Abaikan teks tanda tangan elektronik, QR code, catatan BSrE/TTE, dan footer halaman.
- Jangan mengarang. Jika tidak ada di teks, isi null.`;

const TIMEOUT_MS = 45000;
const PER_MODEL_RETRY = 1; // ulang 1x di model yang sama (khusus error 5xx) sebelum pindah ke model cadangan
const ROUNDS = 2; // jika semua model sibuk, tunggu sebentar lalu coba seluruh daftar sekali lagi
const ROUND_WAIT_MS = 5000;
const QUOTA_WAIT_MS = 15000; // jeda antar putaran bila penyebabnya 429 (kuota per menit)
const COOLDOWN_MS = 60000; // model yang kena 429 dilewati selama ini pada surat-surat berikutnya
const TOTAL_BUDGET_MS = 150000; // batas total satu surat; lewat ini berhenti dan pakai Regex
const RETRY_STATUS = new Set([500, 502, 503, 504]);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cooldown = new Map(); // "provider/model" -> waktu (ms) sampai boleh dicoba lagi

const LABEL = (provider) => (provider === 'openai' ? 'OpenAI API' : 'Gemini API');
const shortErr = (e) => (e.status ? `HTTP ${e.status}` : String(e.message).slice(0, 80));

/** Susun permintaan sesuai penyedia. `input` = { text, pdf? (Buffer) }. */
function buildRequest(provider, model, input, withThinking) {
  if (provider.name === 'openai') {
    const content = [];
    if (input.pdf) {
      content.push({
        type: 'file',
        file: {
          filename: 'surat.pdf',
          file_data: `data:application/pdf;base64,${input.pdf.toString('base64')}`,
        },
      });
    }
    content.push({ type: 'text', text: input.text });
    const body = {
      model,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content },
      ],
      response_format: { type: 'json_object' },
      max_completion_tokens: 8192, // sudah termasuk token penalaran
    };
    // temperature sengaja tidak dikirim (model penalaran hanya menerima nilai bawaan).
    if (withThinking && config.aiThinking) body.reasoning_effort = config.aiThinking;
    return {
      url: `${config.aiBaseUrl}/chat/completions`,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${provider.key}` },
      body: JSON.stringify(body),
    };
  }

  // Gemini: temperature dibiarkan default (Google menyarankan 1.0; di bawah itu bisa looping/menurun).
  const parts = [];
  if (input.pdf) parts.push({ inlineData: { mimeType: 'application/pdf', data: input.pdf.toString('base64') } });
  parts.push({ text: input.text });
  const generationConfig = { responseMimeType: 'application/json', maxOutputTokens: 4096 };
  if (withThinking && config.aiThinking) generationConfig.thinkingConfig = { thinkingLevel: config.aiThinking };
  return {
    url: `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    headers: { 'content-type': 'application/json', 'x-goog-api-key': provider.key },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: [{ role: 'user', parts }],
      generationConfig,
    }),
  };
}

async function request(provider, model, input, withThinking) {
  const label = LABEL(provider.name);
  const { url, headers, body } = buildRequest(provider, model, input, withThinking);
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers, body, signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (e) {
    if (e.name === 'TimeoutError' || e.name === 'AbortError') {
      const te = new Error(`${label} timeout (>${TIMEOUT_MS / 1000} detik)`);
      te.timeout = true;
      throw te;
    }
    throw new Error(`${label} tidak terjangkau: ${e.message}`);
  }
  if (!res.ok) {
    const err = new Error(`${label} ${res.status}: ${(await res.text()).slice(0, 200)}`);
    err.status = res.status;
    throw err;
  }
  return { provider: provider.name, body: await res.json() };
}

/** Model tidak ada / belum boleh dipakai akun ini (bukan masalah key atau kuota). */
function isModelUnavailable(e) {
  if (e.status === 404) return true;
  return (
    (e.status === 400 || e.status === 403) &&
    /model/i.test(e.message) &&
    /not found|not exist|(no|not have|without) access|not allowed|not available|not supported|unknown model|invalid model|deprecated|must be verified/i.test(e.message)
  );
}

/**
 * Kirim permintaan ke daftar "penyedia > model" (penyedia utama dulu, lalu cadangan).
 * - 429 (kuota): langsung pindah ke model/penyedia berikutnya, model itu dilewati 1 menit.
 * - 5xx / timeout: ulang sebentar lalu pindah.
 * - key salah (401/403): penyedia itu dilewati, penyedia lain tetap dicoba.
 * Pindahan hanya berlaku untuk permintaan ini; permintaan berikutnya tetap mulai dari awal daftar.
 */
async function requestWithRetry(input) {
  const chain = [];
  for (const p of config.activeProviders()) for (const m of p.models) chain.push({ p, model: m, id: `${p.name}/${m}` });
  if (!chain.length) throw new Error('Tidak ada API key AI yang aktif');

  let withThinking = true;
  let lastErr;
  const badProviders = new Set();
  const deadline = Date.now() + TOTAL_BUDGET_MS;

  for (let round = 0; round < ROUNDS; round++) {
    let usable = chain.filter((c) => !badProviders.has(c.p.name));
    if (!usable.length) break;
    const ready = usable.filter((c) => (cooldown.get(c.id) || 0) <= Date.now());
    usable = ready.length ? ready : usable; // semua sedang cooldown: coba saja semuanya

    for (let i = 0; i < usable.length; i++) {
      const { p, model, id } = usable[i];
      if (badProviders.has(p.name)) continue;
      if (Date.now() > deadline) throw lastErr || new Error('AI melewati batas waktu total');

      for (let attempt = 0; attempt <= PER_MODEL_RETRY; attempt++) {
        try {
          return await request(p, model, input, withThinking);
        } catch (e) {
          lastErr = e;
          if (e.status === 400 && withThinking && config.aiThinking && /think|reasoning/i.test(e.message)) {
            withThinking = false; // model tidak mendukung pengaturan itu, coba tanpa
            attempt--;
            continue;
          }
          if (isModelUnavailable(e) || e.timeout) break; // model tidak ada / terlalu lambat: berikutnya
          if (e.status === 429) {
            cooldown.set(id, Date.now() + COOLDOWN_MS);
            break; // kuota habis: mengulang di model yang sama percuma
          }
          if (e.status && !RETRY_STATUS.has(e.status)) {
            badProviders.add(p.name); // key salah / permintaan ditolak: lewati penyedia ini
            console.error(`[AI] ${LABEL(p.name)} ditolak (${shortErr(e)}), periksa API key-nya`);
            break;
          }
          if (attempt < PER_MODEL_RETRY) {
            console.error(`[AI] ${id} gagal (${shortErr(e)}), mengulang...`);
            await sleep(config.aiRetryMs * (attempt + 1));
            continue;
          }
          break;
        }
      }

      const next = usable.slice(i + 1).find((c) => !badProviders.has(c.p.name));
      const why = lastErr && lastErr.status === 429 ? 'kuota habis (429)' : 'sibuk/tidak tersedia';
      if (!badProviders.has(p.name)) {
        console.error(`[AI] ${id} ${why}${next ? `, beralih ke ${next.id}` : ''}`);
      }
    }
    if (round < ROUNDS - 1) {
      console.error('[AI] semua model gagal, menunggu sebentar lalu mencoba lagi...');
      await sleep(lastErr && lastErr.status === 429 ? QUOTA_WAIT_MS : ROUND_WAIT_MS);
    }
  }
  throw lastErr;
}

/** Ambil teks balasan dari bentuk respons masing-masing penyedia. */
function readOutput({ provider, body }) {
  const label = LABEL(provider);
  if (provider === 'openai') {
    const choice = body.choices?.[0];
    const msg = choice?.message;
    if (msg?.refusal) throw new Error(`${label} menolak permintaan: ${String(msg.refusal).slice(0, 100)}`);
    if (choice?.finish_reason === 'content_filter') throw new Error(`${label} memblokir permintaan (content_filter)`);
    const out = typeof msg?.content === 'string' ? msg.content : '';
    if (!out.trim()) {
      throw new Error(`${label} membalas kosong${choice?.finish_reason ? ` (${choice.finish_reason})` : ''}`);
    }
    return out;
  }
  if (body.promptFeedback?.blockReason) {
    throw new Error(`${label} memblokir permintaan (${body.promptFeedback.blockReason})`);
  }
  const cand = body.candidates?.[0];
  const out = (cand?.content?.parts || []).filter((p) => !p.thought).map((p) => p.text || '').join('');
  if (!out.trim()) {
    throw new Error(`${label} membalas kosong${cand?.finishReason ? ` (${cand.finishReason})` : ''}`);
  }
  return out;
}

function extractJson(text) {
  const t = text.replace(/```json|```/g, '').trim();
  try {
    return JSON.parse(t);
  } catch {
    const a = t.indexOf('{');
    const b = t.lastIndexOf('}');
    if (a >= 0 && b > a) {
      try {
        return JSON.parse(t.slice(a, b + 1));
      } catch {}
    }
    throw new Error('AI: balasan bukan JSON yang valid');
  }
}

const clean = (v) => (typeof v === 'string' && v.trim() && v.trim() !== '-' ? v.trim() : null);

/** Samakan format tanggal ke DD/MM/YYYY; rentang atau teks lain dibiarkan apa adanya. */
function cleanDate(v) {
  const s = clean(v);
  if (!s) return null;
  const m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/);
  if (m) return `${m[1].padStart(2, '0')}/${m[2].padStart(2, '0')}/${m[3]}`;
  return normalizeDate(s) || s;
}

function normalizeStatus(v) {
  const s = String(v || '').trim().toLowerCase();
  return { biasa: 'Biasa', undangan: 'Undangan', kunjungan: 'Kunjungan' }[s] || null;
}

async function callAI(input) {
  const res = await requestWithRetry(input);
  const out = readOutput(res);

  const json = extractJson(out);
  return {
    status: normalizeStatus(json.status),
    nomor: clean(json.nomor),
    tanggal: cleanDate(json.tanggal),
    pengirim: clean(json.pengirim),
    tujuan: clean(json.tujuan),
    perihal: clean(json.perihal),
    tanggalAcara: cleanDate(json.tanggalAcara),
    jamAcara: clean(json.jamAcara),
    tempat: clean(json.tempat),
  };
}

/** Surat berupa teks (PDF digital). */
async function parseWithAI(text) {
  return callAI({ text: text.slice(0, 8000) });
}

/** PDF scan/gambar: kirim file langsung ke AI, yang membaca gambarnya (OCR). */
async function parseScanWithAI(pdfBuffer) {
  return callAI({
    pdf: pdfBuffer,
    text: 'Ini adalah surat hasil scan. Baca isi gambarnya lalu ekstrak datanya sesuai aturan.',
  });
}

module.exports = { parseWithAI, parseScanWithAI };
