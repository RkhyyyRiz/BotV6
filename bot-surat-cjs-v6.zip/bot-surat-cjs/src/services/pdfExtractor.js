// Impor langsung ke lib/ agar tidak memicu mode debug bawaan pdf-parse v1.
const pdfParse = require('pdf-parse/lib/pdf-parse.js');

async function extractTextFromPdf(buffer) {
  const data = await pdfParse(buffer);
  return data.text || '';
}

module.exports = { extractTextFromPdf };
