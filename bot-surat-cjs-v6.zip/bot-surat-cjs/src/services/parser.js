const { DATE_RE, normalizeDate } = require('../utils/date');

const STOP_RE =
  /^(Yth|Kepada|Di\b|Lampiran|Sifat|Nomor|No\.|Perihal|Hal\s*:|Hari|Tanggal|Waktu|Pukul|Jam|Tempat|Lokasi|Acara|Dengan hormat|Sehubungan|Berdasarkan|Bersama|Bapak|Ibu|Sdr)/i;

const KOP_RE =
  /^(PEMERINTAH|PROVINSI|PROPINSI|KABUPATEN|KOTA|KEMENTERIAN|DINAS|BADAN|SEKRETARIAT|KANTOR|UNIVERSITAS|POLITEKNIK|INSTITUT|SEKOLAH|DEWAN|KOMISI|LEMBAGA|BALAI|RSUD|YAYASAN|BAPPEDA|INSPEKTORAT|SATUAN|UPT|PT\.?|CV\.?)\b/i;

const ADDRESS_RE = /^(Jl\.|Jalan|Telp|Telepon|Email|Website|Faks|Fax|Kode Pos)/i;

/** Ambil nilai setelah "Label :" dan gabungkan maksimal 2 baris lanjutan. */
function getField(lines, labelPattern) {
  const re = new RegExp(`^(?:${labelPattern})\\s*[:：]\\s*(.*)$`, 'i');
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(re);
    if (!m) continue;
    let value = m[1].trim();
    let j = i + 1;
    if (!value && lines[j]) value = lines[j++].trim();
    for (let k = 0; k < 2 && lines[j]; k++, j++) {
      const next = lines[j];
      if (STOP_RE.test(next) || DATE_RE.test(next) || /^\d+[.)]\s/.test(next) || /^[^:]{1,25}:/.test(next)) break;
      value += ' ' + next;
    }
    value = value.replace(/\s+/g, ' ').trim();
    if (value) return value;
  }
  return null;
}

function detectStatus(perihal, text) {
  const p = (perihal || '').toLowerCase();
  const t = text.slice(0, 3000).toLowerCase();
  if (/undangan|mengundang/.test(p)) return 'Undangan';
  if (/kunjungan|audiensi|studi banding|studi tiru|studi lapangan/.test(p)) return 'Kunjungan';
  if (/mengundang|dengan ini kami undang/.test(t)) return 'Undangan';
  if (/kunjungan|audiensi|studi banding|studi tiru/.test(t)) return 'Kunjungan';
  return 'Biasa';
}

function toTitleCase(str) {
  const small = new Set(['dan', 'di', 'ke', 'dari', 'untuk', 'yang']);
  return str
    .toLowerCase()
    .split(' ')
    .map((w, i) => (i > 0 && small.has(w) ? w : w.charAt(0).toUpperCase() + w.slice(1)))
    .join(' ');
}

/** Kop surat: baris-baris nama instansi paling atas, berhenti di alamat/laman/pos-el. */
function detectSender(lines) {
  const kop = [];
  const isCaps = (l) => /[A-Z]/.test(l) && l === l.toUpperCase();
  for (const l of lines.slice(0, 12)) {
    if (ADDRESS_RE.test(l) || /https?:\/\/|www\.|@/i.test(l)) {
      if (kop.length) break;
      continue;
    }
    // Baris kop: diawali kata instansi, atau (setelah kop dimulai) baris huruf besar lanjutan
    if (KOP_RE.test(l) || (kop.length && isCaps(l))) kop.push(l);
    else if (kop.length) break;
    if (kop.length === 4) break;
  }
  if (!kop.length) return null;
  return kop
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .map((l) => (l === l.toUpperCase() ? toTitleCase(l) : l))
    .join(', ');
}

/** Penerima surat keluar: baris setelah "Yth." / "Kepada", berhenti di "di-" / "Tempat" / awal isi surat. */
function detectRecipient(lines) {
  const i = lines.findIndex((l) => /^(Kepada\s+)?Yth\b/i.test(l) || /^Kepada\b/i.test(l));
  if (i < 0) return null;

  const END_RE = /^(di\b|Tempat\b|Dengan hormat|Sehubungan|Berdasarkan|Bersama|Menindaklanjuti|Salam)/i;
  const items = [];
  const first = lines[i].replace(/^(Kepada\s+)?(Yth\.?)?\s*(Kepada)?\s*[:.]?\s*/i, '').trim();
  if (first) items.push(first);

  let j = i + 1;
  for (; j < lines.length && items.length < 6; j++) {
    const l = lines[j];
    if (END_RE.test(l) || DATE_RE.test(l)) break;
    items.push(l);
  }

  // "di- Banjarmasin" ikut dicatat, "di- Tempat" diabaikan
  if (lines[j] && /^di\b/i.test(lines[j])) {
    const m = lines[j].match(/^di\s*-?\s*(.*)$/i);
    const loc = (m && m[1].trim()) || (lines[j + 1] || '').trim();
    if (loc && !/^tempat$/i.test(loc)) items.push('di ' + loc);
  }

  if (!items.length) return null;
  const sep = items.some((x) => /^\d+[.)]/.test(x)) ? '; ' : ' ';
  return items.join(sep).replace(/\s+/g, ' ').trim();
}

function detectLetterDate(lines, acaraLine) {
  for (const l of lines.slice(0, 25)) {
    if (/^(Hari|Tanggal|Waktu|Pukul)/i.test(l)) continue;
    if (DATE_RE.test(l)) return normalizeDate(l);
  }
  for (const l of lines) {
    if (l !== acaraLine && DATE_RE.test(l)) return normalizeDate(l);
  }
  return null;
}

function parseLetter(rawText) {
  const text = rawText.replace(/\r/g, '').replace(/[ \t]+/g, ' ');
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  // Nomor surat (boleh tanpa titik dua, isi boleh di baris berikutnya)
  let nomor = null;
  for (let i = 0; i < Math.min(lines.length, 40); i++) {
    const m = lines[i].match(/^(?:Nomor|No\.)\s*(?:Surat)?\s*[:\uFF1A.]?\s*(.*)$/i);
    if (!m) continue;
    let v = m[1].trim();
    if (!v || v === ':') v = (lines[i + 1] || '').replace(/^[:\uFF1A]\s*/, '').trim();
    if (/\d/.test(v)) {
      nomor = v;
      break;
    }
  }

  const perihal = getField(lines, 'Perihal|Hal');
  const hariTanggal = getField(lines, 'Hari\\s*(?:[,/]|dan)?\\s*(?:Tanggal)?|Tanggal');
  const waktu = getField(lines, 'Pukul|Jam|Waktu');
  const tempat = getField(lines, 'Tempat|Lokasi');

  // Surat sering memisah "Hari : Rabu" dan "Tanggal : 18 November 2026" di baris berbeda.
  const tglOnly = getField(lines, 'Tanggal');
  // Utamakan baris "Hari/Tanggal" yang memuat tanggal; "Tanggal :" tersendiri hanya jika tidak ada.
  const tanggalAcara =
    normalizeDate(hariTanggal) || normalizeDate(tglOnly) || normalizeDate(waktu) || tglOnly || hariTanggal || null;

  let jamAcara = waktu;
  if (jamAcara && DATE_RE.test(jamAcara) && !/\d{1,2}[.:]\d{2}/.test(jamAcara)) jamAcara = null;

  const data = {
    status: detectStatus(perihal, text),
    nomor,
    tanggal: detectLetterDate(lines, hariTanggal),
    pengirim: detectSender(lines),
    tujuan: detectRecipient(lines),
    perihal,
    tanggalAcara,
    jamAcara,
    tempat,
  };

  // Surat biasa umumnya tidak punya acara
  if (data.status === 'Biasa' && !hariTanggal && !waktu && !tempat) {
    data.tanggalAcara = data.jamAcara = data.tempat = null;
  }
  return data;
}

module.exports = { parseLetter };
