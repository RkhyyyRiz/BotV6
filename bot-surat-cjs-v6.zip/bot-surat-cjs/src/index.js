const fs = require('node:fs');
const { config } = require('./config');
const { createWhatsApp } = require('./whatsapp/client');
const { handleMessage, recoverPending } = require('./whatsapp/handler');
const { startWebServer } = require('./web/server');
const { askKeysInBackground, askPairingInBackground } = require('./utils/setup');
const { acquire } = require('./utils/lock');
const { state, LABELS } = require('./whatsapp/state');

fs.mkdirSync(config.dataDir, { recursive: true });

// Dijalankan lewat supervisor (npm start) atau pm2: proses yang mati akan dihidupkan lagi otomatis.
const canRespawn = process.env.BOT_SUPERVISED === '1' || !!process.env.pm_id;
const errorTimes = [];
let lastSoftRestart = 0;
let wa = null;

function onFatal(kind, e) {
  console.error(`[${kind}]`, e);
  const now = Date.now();
  errorTimes.push(now);
  while (errorTimes.length && now - errorTimes[0] > 60000) errorTimes.shift();
  if (errorTimes.length >= 8 && canRespawn) {
    console.error('🔁 Terlalu banyak error beruntun, proses dimulai ulang otomatis...');
    process.exit(1);
  }
  if (errorTimes.length >= 3 && wa && now - lastSoftRestart > 30000) {
    lastSoftRestart = now;
    wa.restart(`error beruntun (${kind})`).catch(() => {});
  }
}
process.on('unhandledRejection', (e) => onFatal('unhandledRejection', e));
process.on('uncaughtException', (e) => onFatal('uncaughtException', e));

async function main() {
  if (process.env.BOT_SUPERVISED !== '1') {
    const lock = acquire();
    if (!lock.ok) {
      console.log(`ℹ️ Bot sudah berjalan (pid ${lock.pid}). Lihat log: npm run log  |  hentikan: npm run stop`);
      process.exit(0);
    }
  }
  const chain = config.activeProviders().map((p) => `${p.name}: ${p.models.join(' > ')}`).join('  ||  ');
  console.log(`Bot Surat Masuk dimulai (mode parsing: ${config.useAI ? `AI [${chain}] + Regex` : 'Regex'})`);
  // Pesan yang menumpuk saat bot mati dibalas begitu tersambung (lewat handler); sisa yang belum selesai dipulihkan di sini.
  wa = createWhatsApp(handleMessage, { onOpen: recoverPending });
  const server = await startWebServer(wa);
  await wa.start();
  startHeartbeat();

  // Pertanyaan di terminal berjalan paralel (tidak memblokir bot) dan otomatis tertutup bila diisi lewat halaman web.
  // Dilewati saat dijalankan ulang oleh supervisor, atau tanpa terminal interaktif (mis. Codespace menyala di latar belakang).
  const webUrl = server ? `http://localhost:${server.address().port}` : '(halaman web nonaktif)';
  if (process.env.BOT_ASK !== '0') {
    askKeysInBackground(webUrl);
    askPairingInBackground((n) => wa.setPairingNumber(n).catch(() => {}), () => wa.hasPairingNumber());
  }
}

/**
 * Cetak satu baris status tiap beberapa menit. Di Codespaces, keluaran terminal dihitung sebagai aktivitas,
 * jadi timer idle ikut di-reset selama terminal tempat bot berjalan masih terbuka. Matikan dengan HEARTBEAT_MIN=0.
 */
function startHeartbeat() {
  const minutes = process.env.HEARTBEAT_MIN === undefined ? 5 : Number(process.env.HEARTBEAT_MIN);
  if (!(minutes > 0)) return;
  const fmt = (sec) => `${Math.floor(sec / 3600)}j ${Math.floor((sec % 3600) / 60)}m`;
  setInterval(() => {
    const jam = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Makassar', hour: '2-digit', minute: '2-digit' });
    console.log(`💓 ${jam} WITA | ${LABELS[state.status] || state.status} | aktif ${fmt(process.uptime())}`);
  }, minutes * 60000).unref();
}

main().catch((e) => {
  console.error('[main]', e);
  process.exit(1);
});
