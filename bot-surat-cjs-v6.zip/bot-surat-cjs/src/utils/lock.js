const fs = require('node:fs');
const path = require('node:path');
const { config } = require('../config');

const lockFile = () => path.join(config.dataDir, 'bot.lock');

function readLock() {
  try {
    return Number(fs.readFileSync(lockFile(), 'utf8').trim()) || 0;
  } catch {
    return 0;
  }
}

/** Apakah pid itu proses bot yang masih hidup? (Di Linux dicek juga nama prosesnya agar pid bekas tidak salah dikira.) */
function alive(pid) {
  if (!pid || pid === process.pid) return false;
  try {
    process.kill(pid, 0);
  } catch {
    return false;
  }
  try {
    return /src[\\/](supervisor|index)\.js/.test(fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8'));
  } catch {
    return true; // tanpa /proc (Windows/macOS): anggap hidup
  }
}

/** Satu bot saja per sesi WhatsApp. Dua proses dengan sesi sama akan saling mengeluarkan (kode 440). */
function acquire() {
  fs.mkdirSync(config.dataDir, { recursive: true });
  const other = readLock();
  if (alive(other)) return { ok: false, pid: other };
  fs.writeFileSync(lockFile(), String(process.pid));
  process.on('exit', () => {
    try {
      if (readLock() === process.pid) fs.rmSync(lockFile());
    } catch {}
  });
  return { ok: true };
}

module.exports = { acquire, readLock, alive };
