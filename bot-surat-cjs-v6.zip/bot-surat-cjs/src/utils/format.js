const COMMON = [
  ['status', 'Status Surat'],
  ['nomor', 'Nomor Surat'],
  ['tanggal', 'Tanggal Surat'],
];
const EVENT = [
  ['tanggalAcara', 'Tanggal Acara'],
  ['jamAcara', 'Jam Acara'],
  ['tempat', 'Tempat Acara'],
];
// Surat masuk punya Pengirim, surat keluar punya Tujuan.
const PARTY = { masuk: ['pengirim', 'Pengirim'], keluar: ['tujuan', 'Tujuan'] };
const TITLE = { masuk: 'SURAT MASUK', keluar: 'SURAT KELUAR' };

function fieldsFor(jenis = 'masuk') {
  return [...COMMON, PARTY[jenis], ['perihal', 'Perihal'], ...EVENT];
}

const ALL_KEYS = ['status', 'nomor', 'tanggal', 'pengirim', 'tujuan', 'perihal', 'tanggalAcara', 'jamAcara', 'tempat'];

/** Isi field kosong di `primary` dengan nilai dari `fallback` (semua field, pengirim maupun tujuan). */
function mergeFields(primary, fallback) {
  const out = {};
  for (const k of ALL_KEYS) out[k] = primary?.[k] ?? fallback?.[k] ?? null;
  return out;
}

/** Field wajib yang belum terbaca. Field acara hanya wajib untuk Undangan/Kunjungan. */
function findMissing(d, jenis = 'masuk') {
  const required = ['nomor', 'tanggal', PARTY[jenis][0], 'perihal'];
  if (d.status !== 'Biasa') required.push('tanggalAcara', 'jamAcara', 'tempat');
  return required.filter((k) => !d[k]);
}

function formatTranscript(d, missing = [], jenis = 'masuk') {
  const fields = fieldsFor(jenis);
  const label = Object.fromEntries(fields);
  const lines = fields
    .map(([k, name]) => {
      if ((k === 'tanggalAcara' || k === 'jamAcara' || k === 'tempat') && d.status === 'Biasa' && !d[k]) {
        return null;
      }
      return `*${name}*\n${d[k] || '-'}`;
    })
    .filter(Boolean);

  let out = `📄 *HASIL EKSTRAKSI ${TITLE[jenis]}*\n\n` + lines.join('\n\n');
  if (missing.length) {
    out += `\n\n⚠️ Perlu dicek manual: ${missing.map((k) => label[k]).join(', ')}`;
  }
  return out;
}

module.exports = { mergeFields, findMissing, formatTranscript, fieldsFor, PARTY, TITLE };
