const { config } = require('../config');

const norm = (s) => (s || '').toUpperCase().replace(/\s+/g, ' ');

/** True jika teks kop memuat semua kata kunci salah satu grup OWN_KOP dan bukan kop provinsi/pusat. */
function isOwnKop(kop) {
  const t = norm(kop);
  if (!t) return false;
  if (/PROVINSI|PROPINSI|KEMENTERIAN|REPUBLIK INDONESIA/.test(t)) return false;
  return config.ownKop.some((group) => group.every((k) => t.includes(k)));
}

/** 'keluar' bila salah satu kop yang terbaca adalah kop instansi sendiri, selain itu 'masuk'. */
function detectJenis(...kops) {
  return kops.some(isOwnKop) ? 'keluar' : 'masuk';
}

module.exports = { isOwnKop, detectJenis };
