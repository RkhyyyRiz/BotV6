/** Rapikan nomor WhatsApp jadi digit saja berawalan kode negara (contoh 628123456789). Kosong = tidak valid. */
function normalizeNumber(value) {
  const cc = String(process.env.COUNTRY_CODE || '62').replace(/\D/g, '') || '62';
  let d = String(value || '').replace(/\D/g, '');
  if (!d) return '';
  if (d.startsWith('00')) d = d.slice(2);
  else if (d.startsWith('0')) d = cc + d.slice(1); // 0812... -> 62812...
  else if (cc === '62' && d.startsWith('8')) d = cc + d; // 812... -> 62812...
  if (d.length < 8 || d.length > 15) return '';
  return d;
}

module.exports = { normalizeNumber };
