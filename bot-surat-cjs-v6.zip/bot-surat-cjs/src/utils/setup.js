const fs = require('node:fs');
const path = require('node:path');
const { config } = require('../config');
const { prompt } = require('./askKey');
const { normalizeNumber } = require('./phone');
const keyStore = require('./keyStore');

/** Sudah ada sesi WhatsApp yang tertaut di folder auth? */
function hasRegisteredSession() {
  try {
    return !!JSON.parse(fs.readFileSync(path.join(config.authDir, 'creds.json'), 'utf8')).registered;
  } catch {
    return false;
  }
}

/**
 * Tanya API key di terminal, TANPA memblokir bot. Pertanyaan otomatis ditutup bila key sudah
 * diisi lewat halaman web. Key terdeteksi dari awalannya: AIza... = Gemini, sk-... = OpenAI.
 * Hanya bertanya bila belum ada key sama sekali. Mengembalikan fungsi untuk membatalkan.
 */
function askKeysInBackground(webUrl) {
  if (process.env.USE_AI === 'false' || config.activeProviders().length > 0) return () => {};
  if (!process.stdin.isTTY) {
    console.warn(`ℹ️ API key AI belum diisi. Tempel lewat halaman web: ${webUrl}  (atau Secrets / .env). Tanpa key, PDF scan tidak terbaca.`);
    return () => {};
  }
  const p = prompt(`🔑 Tempel API key (Gemini AIza... / OpenAI sk-...) lalu Enter, atau isi lewat web ${webUrl}\n   (kosongkan untuk lewati): `, { hidden: true });
  const onChange = () => {
    if (config.activeProviders().length > 0) p.cancel('✅ API key diterima dari halaman web.');
  };
  keyStore.events.on('change', onChange);
  p.promise.then((raw) => {
    keyStore.events.off('change', onChange);
    const key = keyStore.cleanKey(raw);
    if (!key) return;
    const target = keyStore.detectProvider(key, config.aiProvider);
    keyStore.save(config, target, key);
    console.log(`✅ API key ${target} disimpan (${keyStore.mask(key)}).`);
  });
  return () => p.cancel();
}

/**
 * Tanya nomor untuk kode pairing di terminal, tanpa memblokir bot, hanya bila belum ada sesi tertaut.
 * Ditutup otomatis bila nomor sudah diisi lewat halaman web. `onNumber` menerima nomor yang sudah dinormalkan.
 */
function askPairingInBackground(onNumber, isSet) {
  if (process.env.PAIRING_NUMBER || hasRegisteredSession() || !process.stdin.isTTY) return () => {};
  const p = prompt('📱 Nomor WhatsApp bot untuk kode pairing (contoh 628123456789), Enter kosong = pakai QR/web: ');
  const timer = setInterval(() => {
    if (isSet()) {
      clearInterval(timer);
      p.cancel('✅ Nomor diterima dari halaman web.');
    }
  }, 1000);
  timer.unref();
  p.promise.then((raw) => {
    clearInterval(timer);
    if (!raw) return;
    const n = normalizeNumber(raw);
    if (!n) return console.warn('⚠️ Nomor tidak valid, dilewati. Bisa diisi lewat halaman web.');
    onNumber(n);
  });
  return () => p.cancel();
}

module.exports = { askKeysInBackground, askPairingInBackground, hasRegisteredSession };
