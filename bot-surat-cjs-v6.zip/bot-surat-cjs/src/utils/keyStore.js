/**
 * Penyimpanan API key yang diisi lewat halaman web / terminal.
 * Disimpan di data/keys.json (izin 0600, folder data/ sudah di .gitignore) supaya bot yang dijalankan
 * ulang (supervisor, Codespace dihidupkan lagi) tidak perlu ditempeli key lagi.
 * Key di sini menimpa key dari .env / Secret.
 */
const fs = require('node:fs');
const path = require('node:path');
const { EventEmitter } = require('node:events');

const FILE = path.join('./data', 'keys.json');
const PROVIDERS = ['gemini', 'openai'];
const events = new EventEmitter();

/** Tebak penyedia dari awalan key; kalau tidak dikenali pakai `fallback`. */
function detectProvider(key, fallback) {
  if (/^sk-/.test(key)) return 'openai';
  if (/^AIza/.test(key)) return 'gemini';
  return fallback;
}

/** Bersihkan hasil tempel: spasi, baris baru, tanda kutip, dan awalan "KEY=". */
function cleanKey(raw) {
  return String(raw || '')
    .trim()
    .replace(/^[A-Z_]*API_KEY\s*=\s*/i, '')
    .replace(/^["'`]+|["'`]+$/g, '')
    .replace(/\s+/g, '');
}

function read() {
  try {
    const data = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    const out = {};
    for (const p of PROVIDERS) if (typeof data[p] === 'string' && data[p]) out[p] = data[p];
    return out;
  } catch {
    return {};
  }
}

function write(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, FILE);
  try {
    fs.chmodSync(FILE, 0o600);
  } catch {}
}

/** Simpan key + pasang ke config yang sedang berjalan. */
function save(config, provider, key) {
  const data = read();
  data[provider] = key;
  write(data);
  config.keys[provider] = key;
  events.emit('change', provider);
}

/** Hapus key tersimpan. Key dari .env / Secret (jika ada) dipakai kembali. */
function remove(config, provider, envValue) {
  const data = read();
  delete data[provider];
  write(data);
  config.keys[provider] = envValue || '';
  events.emit('change', provider);
}

/** Hanya 4 karakter terakhir yang boleh tampil di layar. */
const mask = (key) => (key ? `••••${key.slice(-4)}` : '');

module.exports = { read, save, remove, detectProvider, cleanKey, mask, events, PROVIDERS };
