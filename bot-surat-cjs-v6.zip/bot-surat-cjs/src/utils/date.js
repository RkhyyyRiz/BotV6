const MONTHS = [
  'januari', 'februari', 'maret', 'april', 'mei', 'juni',
  'juli', 'agustus', 'september', 'oktober', 'november', 'desember',
];

const DATE_RE = new RegExp(`(\\d{1,2})\\s+(${MONTHS.join('|')})\\s+(\\d{4})`, 'i');

/** "16 November 2026" -> "16/11/2026". Mengembalikan null jika tidak ada tanggal. */
function normalizeDate(str) {
  if (!str) return null;
  const m = str.match(DATE_RE);
  if (!m) return null;
  const dd = m[1].padStart(2, '0');
  const mm = String(MONTHS.indexOf(m[2].toLowerCase()) + 1).padStart(2, '0');
  return `${dd}/${mm}/${m[3]}`;
}

const nowWIB = () =>
  new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

module.exports = { DATE_RE, normalizeDate, nowWIB };
