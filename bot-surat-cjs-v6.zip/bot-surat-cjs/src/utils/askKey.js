const readline = require('node:readline');

/**
 * Pertanyaan di terminal yang bisa dibatalkan dari luar (mis. saat key sudah diisi lewat halaman web).
 * Mengembalikan { promise, cancel }. Tanpa terminal interaktif langsung selesai dengan ''.
 * hidden=true: input ditampilkan sebagai * (untuk API key). Ctrl+C menghentikan bot seperti biasa.
 */
function prompt(question, { hidden = false } = {}) {
  let rl = null;
  let finish = () => {};
  const promise = new Promise((resolve) => {
    if (!process.stdin.isTTY) return resolve('');
    rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    let done = false;
    finish = (value) => {
      if (done) return;
      done = true;
      try {
        rl.close();
      } catch {}
      resolve(value);
    };
    if (hidden) {
      let asked = false;
      rl._writeToOutput = (str) => {
        if (!asked) {
          asked = true;
          process.stdout.write(str); // tampilkan pertanyaan
        } else if (/^[\r\n]+$/.test(str)) {
          process.stdout.write(str);
        } else {
          process.stdout.write('*'.repeat(Math.max(0, str.replace(/[\r\n]/g, '').length)));
        }
      };
    }
    // Mode raw tidak mengirim sinyal, jadi Ctrl+C harus diteruskan sendiri agar bot bisa dihentikan.
    rl.on('SIGINT', () => {
      finish('');
      if (process.env.BOT_SUPERVISED === '1') process.kill(process.ppid, 'SIGINT');
      else process.exit(130);
    });
    rl.question(question, (answer) => finish(answer.trim()));
  });
  return {
    promise,
    cancel(note) {
      if (!rl) return;
      if (note) process.stdout.write(`\n${note}\n`);
      finish('');
    },
  };
}

const askApiKey = (q) => prompt(q, { hidden: true }).promise;
const askLine = (q) => prompt(q).promise;

module.exports = { prompt, askApiKey, askLine };
