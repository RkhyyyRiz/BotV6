/**
 * Penjaga proses: menjalankan bot (src/index.js) sebagai proses anak, langsung tanpa menunggu input.
 * (Pertanyaan key/nomor di terminal dijalankan paralel oleh bot dan bisa dilewati lewat halaman web.)
 * Bila bot mati/crash, otomatis dijalankan lagi (jeda bertahap 1-30 detik), tanpa menanyakan ulang.
 * Dipakai oleh `npm start`. Hentikan dengan Ctrl+C.
 */
const { spawn } = require('node:child_process');
const path = require('node:path');
const { acquire } = require('./utils/lock');

let child = null;
let stopping = false;
let failures = 0;
let first = true;

function run() {
  const startedAt = Date.now();
  child = spawn(process.execPath, [path.join(__dirname, 'index.js')], {
    stdio: 'inherit',
    env: {
      ...process.env,
      BOT_SUPERVISED: '1',
      // Pertanyaan di terminal hanya pada start pertama; jalan ulang otomatis tidak menanyakan lagi.
      BOT_ASK: first ? '1' : '0',
    },
  });
  first = false;
  child.on('error', (e) => console.error('[supervisor] gagal menjalankan bot:', e.message));
  child.on('exit', (code, signal) => {
    child = null;
    if (stopping) process.exit(0);
    failures = Date.now() - startedAt > 60000 ? 0 : failures + 1;
    const delay = Math.min(30000, 1000 * 2 ** Math.min(failures, 5));
    console.error(`⚠️ Bot berhenti (${signal || `kode ${code}`}). Dijalankan ulang otomatis dalam ${Math.round(delay / 1000)} detik...`);
    setTimeout(run, delay);
  });
}

function stop() {
  if (stopping) return;
  stopping = true;
  if (!child) process.exit(0);
  child.kill('SIGTERM');
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

(async () => {
  const lock = acquire();
  if (!lock.ok) {
    console.log(`ℹ️ Bot sudah berjalan (pid ${lock.pid}). Lihat log: npm run log  |  hentikan: npm run stop`);
    process.exit(0);
  }
  run();
})();
