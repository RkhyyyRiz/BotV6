// npm run stop: hentikan bot yang berjalan (mis. yang dinyalakan otomatis di latar belakang).
const { readLock, alive } = require('./utils/lock');

const pid = readLock();
if (!alive(pid)) {
  console.log('Bot tidak sedang berjalan.');
} else {
  process.kill(pid, 'SIGTERM');
  console.log(`Bot (pid ${pid}) dihentikan.`);
}
